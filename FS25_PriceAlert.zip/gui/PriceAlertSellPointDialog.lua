-- PriceAlertSellPointDialog.lua

PriceAlertSellPointDialog = {}
local PriceAlertSellPointDialog_mt = Class(PriceAlertSellPointDialog, MessageDialog)

function PriceAlertSellPointDialog.new(target, custom_mt)
    local self = MessageDialog.new(target, custom_mt or PriceAlertSellPointDialog_mt)
    self.productName     = ""
    self.hudOverlay      = ""
    self.sellPointList_  = {}
    self.selectedSP      = nil
    return self
end

function PriceAlertSellPointDialog:onGuiSetupFinished()
    PriceAlertSellPointDialog:superClass().onGuiSetupFinished(self)
    if self.sellPointList ~= nil then
        self.sellPointList:setDataSource(self)
        self.sellPointList:setDelegate(self)
        self.sellPointList.onSelectionChanged = function(list, section, index)
            self:onListSelectionChanged(list, section, index)
        end
    end
end

function PriceAlertSellPointDialog:initialize()
end

function PriceAlertSellPointDialog:onClose()
    PriceAlertSellPointDialog:superClass().onClose(self)
    self.productName    = ""
    self.hudOverlay     = ""
    self.sellPointList_ = {}
    self.selectedSP     = nil
    if self.btnMark ~= nil then self.btnMark:setDisabled(true) end
end

function PriceAlertSellPointDialog:setData(productName, hudOverlay, sellPoints)
    self.productName    = productName or ""
    self.hudOverlay     = hudOverlay  or ""
    self.sellPointList_ = sellPoints  or {}
    self.selectedSP     = nil

    if self.dialogProductIcon ~= nil then
        if self.hudOverlay ~= nil and self.hudOverlay ~= "" then
            self.dialogProductIcon:setImageFilename(self.hudOverlay)
            self.dialogProductIcon:setVisible(true)
        else
            self.dialogProductIcon:setVisible(false)
        end
    end

    if self.dialogTitle ~= nil then
        local prefix = g_i18n:getText("ui_sellpoint_dialogTitle") or "Punti vendita per"
        self.dialogTitle:setText(prefix .. ": " .. self.productName)
    end

    if self.btnMark ~= nil then
        self.btnMark:setDisabled(true)
        self.btnMark:setText(g_i18n:getText("ui_sellpoint_btnMark"))
    end

    if self.sellPointList ~= nil then
        self.sellPointList:reloadData()
    end
end

function PriceAlertSellPointDialog:onListSelectionChanged(list, section, index)
    if index >= 1 and index <= #self.sellPointList_ then
        self.selectedSP = self.sellPointList_[index]
    else
        self.selectedSP = nil
    end
    if self.btnMark ~= nil then
        local hasHotspot = self.selectedSP ~= nil and self.selectedSP.hotspot ~= nil
        self.btnMark:setDisabled(not hasHotspot)
        if hasHotspot and self.selectedSP.hotspot == g_currentMission.currentMapTargetHotspot then
            self.btnMark:setText(g_i18n:getText("ui_sellpoint_btnUnmark"))
        else
            self.btnMark:setText(g_i18n:getText("ui_sellpoint_btnMark"))
        end
    end
end

function PriceAlertSellPointDialog:getNumberOfItemsInSection(list, section)
    return #self.sellPointList_
end

function PriceAlertSellPointDialog:populateCellForItemInSection(list, section, index, cell)
    local entry = self.sellPointList_[index]
    if entry == nil then return end
    local nameElem = cell:getAttribute("colSpName")
    if nameElem ~= nil then nameElem:setText(entry.name) end
    local tnElem = cell:getAttribute("colSpTotalNow")
    if tnElem ~= nil then tnElem:setText(entry.totalNowStr) end
    local tmElem = cell:getAttribute("colSpTotalMax")
    if tmElem ~= nil then tmElem:setText(entry.totalMaxStr) end
    local pctElem = cell:getAttribute("colSpPct")
    if pctElem ~= nil then pctElem:setText(entry.pctStr) end
end

function PriceAlertSellPointDialog:onClickMark()
    local sp = self.selectedSP
    if sp == nil or sp.hotspot == nil then return end
    if sp.hotspot == g_currentMission.currentMapTargetHotspot then
        g_currentMission:setMapTargetHotspot(nil)
    else
        g_currentMission:setMapTargetHotspot(sp.hotspot)
    end
    self:close()
end

function PriceAlertSellPointDialog:onClickClose()
    self:close()
end

function PriceAlertSellPointDialog:onClickBack()
    self:close()
end
