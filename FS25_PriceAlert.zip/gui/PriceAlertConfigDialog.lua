-- PriceAlertConfigDialog.lua

PriceAlertConfigDialog = {}
local PriceAlertConfigDialog_mt = Class(PriceAlertConfigDialog, MessageDialog)

function PriceAlertConfigDialog.new(target, custom_mt)
    local self = MessageDialog.new(target, custom_mt or PriceAlertConfigDialog_mt)
    self.productName   = ""
    self.productIndex  = nil
    self.hudOverlay    = ""
    self.pctThreshold  = 80
    self.minQty        = 0
    self.stopTimeScale = false
    self.callbackSave  = nil
    return self
end

function PriceAlertConfigDialog:onGuiSetupFinished()
    PriceAlertConfigDialog:superClass().onGuiSetupFinished(self)
end

function PriceAlertConfigDialog:onCreate()
    if PriceAlertConfigDialog:superClass().onCreate ~= nil then
        PriceAlertConfigDialog:superClass().onCreate(self)
    end
end

function PriceAlertConfigDialog:initialize()
end

function PriceAlertConfigDialog:onNumericChanged(element)
    local text = element:getText()
    local clean = text:gsub("%D", "")
    if element == self.inputPct then
        local val = tonumber(clean)
        if val and val > 150 then clean = "150" end
    end
    -- Solo aggiorna se il testo è cambiato per evitare perdita del focus
    if clean ~= text then
        element:setText(clean)
    end
end

function PriceAlertConfigDialog:onOpen()
    PriceAlertConfigDialog:superClass().onOpen(self)
    if self.inputPct ~= nil then
        self.inputPct:setText(self.pctThreshold ~= nil and tostring(self.pctThreshold) or "")
    end
    if self.inputMinQty ~= nil then
        self.inputMinQty:setText(self.minQty ~= nil and tostring(self.minQty) or "")
    end
    if self.optionStopTimeScale ~= nil then
        self.optionStopTimeScale:setState(self.stopTimeScale and 2 or 1)
    end
    FocusManager:setFocus(self.inputPct)
end

function PriceAlertConfigDialog:onClose()
    PriceAlertConfigDialog:superClass().onClose(self)
    self.pctThreshold   = nil
    self.minQty         = nil
    self.stopTimeScale  = false
    self.productName    = ""
    self.ftName         = ""
    self.callbackDelete = nil
end

function PriceAlertConfigDialog:setData(productName, ftName, ftIndex, hudOverlay, pctThreshold, minQty, stopTimeScale, callbackSave, callbackDelete)
    self.productName   = productName   or ""
    self.ftName        = ftName        or ""
    self.productIndex  = ftIndex
    self.hudOverlay    = hudOverlay    or ""
    self.pctThreshold  = pctThreshold
    self.minQty        = minQty
    self.stopTimeScale = stopTimeScale or false
    self.callbackSave  = callbackSave
    self.callbackDelete = callbackDelete

    local hasExisting = (pctThreshold ~= nil)

    -- Pulsante elimina visibile solo se esiste già un alert
    if self.btnDelete ~= nil then
        self.btnDelete:setVisible(hasExisting)
    end
    if self.btnDeleteSeparator ~= nil then
        self.btnDeleteSeparator:setVisible(hasExisting)
    end

    -- Icona prodotto (approccio A)
    if self.dialogProductIcon ~= nil then
        if self.hudOverlay ~= nil and self.hudOverlay ~= "" then
            self.dialogProductIcon:setImageFilename(self.hudOverlay)
            self.dialogProductIcon:setVisible(true)
        else
            self.dialogProductIcon:setVisible(false)
        end
    end

    -- Titolo (approccio A)
    if self.dialogTitle ~= nil then
        local prefix = g_i18n:getText("ui_alert_dialogTitle") or "Alert"
        self.dialogTitle:setText(prefix .. ": " .. self.productName)
        self.dialogTitle:setVisible(true)
    end

    -- Campi form (approccio A)
    if self.inputPct ~= nil then
        self.inputPct:setText(self.pctThreshold ~= nil and tostring(self.pctThreshold) or "")
    end
    if self.inputMinQty ~= nil then
        self.inputMinQty:setText(self.minQty ~= nil and tostring(self.minQty) or "")
    end
    if self.optionStopTimeScale ~= nil then
        self.optionStopTimeScale:setState(self.stopTimeScale and 2 or 1)
    end
end

function PriceAlertConfigDialog:onClickSave()
    local pct    = tonumber(self.inputPct:getText())    or self.pctThreshold
    local minQty = tonumber(self.inputMinQty:getText()) or self.minQty
    local stopTs = false
    if self.optionStopTimeScale ~= nil then
        stopTs = self.optionStopTimeScale:getState() == 2
    end
    pct    = math.max(0, math.min(150, pct))
    minQty = math.max(0, minQty)
    if self.callbackSave ~= nil then
        self.callbackSave(self.productIndex, self.ftName, pct, minQty, stopTs)
    end
    self:close()
end

function PriceAlertConfigDialog:onClickDelete()
    if self.callbackDelete ~= nil then
        self.callbackDelete(self.ftName)
    end
    self:close()
end

function PriceAlertConfigDialog:onClickCancel()
    self:close()
end

function PriceAlertConfigDialog:onClickBack()
    self:close()
end
