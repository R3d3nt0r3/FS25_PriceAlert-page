-- PriceAlertStorageDialog.lua

PriceAlertVehicleHotspot = {}
local PriceAlertVehicleHotspot_mt = Class(PriceAlertVehicleHotspot, MapHotspot)

function PriceAlertVehicleHotspot.new()
    local self = MapHotspot.new(PriceAlertVehicleHotspot_mt)
    self.width, self.height = getNormalizedScreenValues(100, 100)
    if g_overlayManager and g_overlayManager.createOverlay then
        self.icon = g_overlayManager:createOverlay("mapHotspots.other", 0, 0, self.width, self.height)
    end
    if self.setColor then self:setColor(0.2, 1, 0, 1) end
    if self.setVisible then self:setVisible(true) end
    if self.setBlinking then self:setBlinking(true) end
    return self
end

function PriceAlertVehicleHotspot:getCategory()
    return MapHotspot.CATEGORY_OTHER
end

PriceAlertStorageDialog = {}
local PriceAlertStorageDialog_mt = Class(PriceAlertStorageDialog, MessageDialog)

function PriceAlertStorageDialog.new(target, custom_mt)
    local self = MessageDialog.new(target, custom_mt or PriceAlertStorageDialog_mt)
    self.productName  = ""
    self.hudOverlay   = ""
    self.storageList  = {}
    self.selectedStorage = nil
    return self
end

function PriceAlertStorageDialog:onGuiSetupFinished()
    PriceAlertStorageDialog:superClass().onGuiSetupFinished(self)
    if self.storageList ~= nil then
        self.storageList:setDataSource(self)
        self.storageList:setDelegate(self)
        self.storageList.onSelectionChanged = function(list, section, index)
            self:onListSelectionChanged(list, section, index)
        end
    end
end

function PriceAlertStorageDialog:initialize()
end

function PriceAlertStorageDialog:onClose()
    PriceAlertStorageDialog:superClass().onClose(self)
    self.productName     = ""
    self.hudOverlay      = ""
    self.storageList_    = {}
    self.selectedStorage = nil
    if self.btnMark ~= nil then self.btnMark:setDisabled(true) end
end

function PriceAlertStorageDialog:setData(productName, hudOverlay, storages, customTitle)
    self.productName  = productName or ""
    self.hudOverlay   = hudOverlay  or ""
    self.storageList_ = storages    or {}
    self.customTitle   = customTitle or nil
    self.selectedStorage = nil

    -- Icona prodotto
    if self.dialogProductIcon ~= nil then
        if self.hudOverlay ~= nil and self.hudOverlay ~= "" then
            self.dialogProductIcon:setImageFilename(self.hudOverlay)
            self.dialogProductIcon:setVisible(true)
        else
            self.dialogProductIcon:setVisible(false)
        end
    end

    -- Titolo (approccio A)
    if self.dialogTitle ~= nil then
        local prefix = self.customTitle or g_i18n:getText("ui_storage_dialogTitle") or "Magazzini che contengono"
        self.dialogTitle:setText(prefix .. ": " .. self.productName)
    end

    -- Pulsante contrassegna disabilitato di default
    if self.btnMark ~= nil then self.btnMark:setDisabled(true) end

    -- Ricarica lista
    if self.storageList ~= nil then
        self.storageList:reloadData()
    end
end

function PriceAlertStorageDialog:onListSelectionChanged(list, section, index)
    if index >= 1 and index <= #self.storageList_ then
        self.selectedStorage = self.storageList_[index]
    else
        self.selectedStorage = nil
    end
    local canMark = self.selectedStorage ~= nil and self.selectedStorage.canMark
    if self.btnMark ~= nil then
        self.btnMark:setDisabled(not canMark)
        local isMarked = false
        if canMark then
            if self.selectedStorage.isVehicle then
                isMarked = PriceAlert.currentVehicleHotspot ~= nil and
                           PriceAlert.currentVehicleId == self.selectedStorage.vehicleId
            elseif self.selectedStorage.hotspot ~= nil then
                isMarked = self.selectedStorage.hotspot == g_currentMission.currentMapTargetHotspot
            end
        end
        if isMarked then
            self.btnMark:setText(g_i18n:getText("ui_storage_btnUnmark"))
        else
            self.btnMark:setText(g_i18n:getText("ui_storage_btnMark"))
        end
    end
end

-- Data source
function PriceAlertStorageDialog:getNumberOfItemsInSection(list, section)
    return #self.storageList_
end

function PriceAlertStorageDialog:populateCellForItemInSection(list, section, index, cell)
    local entry = self.storageList_[index]
    if entry == nil then return end
    local nameElem = cell:getAttribute("colStorageName")
    if nameElem ~= nil then nameElem:setText(entry.name) end
    local qtyElem = cell:getAttribute("colStorageQty")
    if qtyElem ~= nil then qtyElem:setText(entry.qtyStr) end
    -- Colore lampeggiante se alert attivo, identico alle tab principali
    local alertColor, alertColorSel
    if entry.isAlert then
        if PriceAlert.alertBlinkState then
            alertColor    = {0.706, 1.0, 0.0, 1.0}
            alertColorSel = {0.706, 1.0, 0.0, 1.0}
        else
            alertColor    = {1.0, 0.4, 0.0, 1.0}
            alertColorSel = {1.0, 0.4, 0.0, 1.0}
        end
    else
        alertColor    = {0.85, 0.85, 0.85, 1.0}
        alertColorSel = {0.1,  0.1,  0.1,  1.0}
    end
    if nameElem ~= nil then nameElem.textColor = alertColor; nameElem.textSelectedColor = alertColorSel end
    if qtyElem  ~= nil then qtyElem.textColor  = alertColor; qtyElem.textSelectedColor  = alertColorSel end
end

function PriceAlertStorageDialog:onClickMark()
    local s = self.selectedStorage
    if s == nil or not s.canMark then return end
    if s.isVehicle and s.worldX ~= nil then
        -- Se il veicolo è già marcato, annulla
        if PriceAlert.currentVehicleHotspot ~= nil and PriceAlert.currentVehicleId == s.vehicleId then
            g_currentMission:removeMapHotspot(PriceAlert.currentVehicleHotspot)
            g_currentMission:setMapTargetHotspot(nil)
            PriceAlert.currentVehicleHotspot:delete()
            PriceAlert.currentVehicleHotspot = nil
            PriceAlert.currentVehicleId = nil
            self:close()
            return
        end
        local hs = PriceAlertVehicleHotspot.new()
        hs:setWorldPosition(s.worldX, s.worldZ)
        -- Categoria e widget
        if hs.setCategory ~= nil then hs:setCategory(MapHotspot.CATEGORY_OTHER) end
        if hs.setMapWidget ~= nil then hs:setMapWidget(g_currentMission.hud.ingameMap) end
        if hs.setPersistent ~= nil then hs:setPersistent(true) end
        if hs.setOwnerFarmId ~= nil then hs:setOwnerFarmId(g_currentMission:getFarmId()) end
        -- Rimuovi hotspot veicolo precedente DOPO aver creato il nuovo
        if PriceAlert.currentVehicleHotspot ~= nil then
            g_currentMission:removeMapHotspot(PriceAlert.currentVehicleHotspot)
            PriceAlert.currentVehicleHotspot:delete()
            PriceAlert.currentVehicleHotspot = nil
            PriceAlert.currentVehicleId = nil
        end
        -- 5. Aggiungi alla mappa e imposta come target per il segnalino distanza
        g_currentMission:addMapHotspot(hs)
        g_currentMission:setMapTargetHotspot(hs)
        PriceAlert.currentVehicleHotspot = hs
        PriceAlert.currentVehicleId = s.vehicleId
        self.vehicleHotspot = hs
        self:close()
    elseif s.hotspot ~= nil then
        if s.hotspot == g_currentMission.currentMapTargetHotspot then
            g_currentMission:setMapTargetHotspot(nil)
        else
            g_currentMission:setMapTargetHotspot(s.hotspot)
        end
        self:close()
    end
end

function PriceAlertStorageDialog:onClickClose()
    self:close()
end

function PriceAlertStorageDialog:onClickBack()
    self:close()
end
