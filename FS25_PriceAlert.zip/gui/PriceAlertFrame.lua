-- PriceAlertFrame.lua

PriceAlertFrame = {}
local PriceAlertFrame_mt = Class(PriceAlertFrame, TabbedMenuFrameElement)

PriceAlertFrame.sortColumn = "title"
PriceAlertFrame.sortAsc    = true
PriceAlertFrame.showAnimals = true
PriceAlertFrame.TAB_ALL        = 1
PriceAlertFrame.TAB_ALERT      = 2
PriceAlertFrame.TAB_UNSELLABLE = 3
PriceAlertFrame.TAB_CONFIG      = 4
PriceAlertFrame.TAB_NAMES  = {
    "ui_tab_allProducts",
    "ui_tab_alertProducts",
    "ui_tab_unsellable",
    "ui_tab_alert",
}
PriceAlertFrame.NUM_TABS = 4

function PriceAlertFrame.new(target)
    local self = TabbedMenuFrameElement.new(target, PriceAlertFrame_mt)
    self.rows            = {}
    self.allRows         = {}
    self.allSellableRows = {}
    self.selectedRow     = nil
    self.currentTab      = PriceAlertFrame.TAB_ALL
    self.subCategoryTabs = {}
    self.priceTable      = nil
    self.priceTableAlert      = nil
    self.priceTableConfig          = nil
    self.priceTableUnsellable = nil
    self.sortColumnConfig     = "product"
    self.sortAscConfig        = true
    self.tagButtonInfo = {
        inputAction = InputAction.MENU_EXTRA_2,
        text        = g_i18n:getText("ui_btn_tagStation"),
        callback    = function() self:onClickTagStation() end,
        disabled    = true,
    }
    self.configAlertButtonInfo = {
        inputAction = InputAction.MENU_EXTRA_1,
        text        = g_i18n:getText("ui_btn_configAlert"),
        callback    = function() self:onClickConfigAlert() end,
        disabled    = true,
    }
    self.storageButtonInfo = {
        inputAction = InputAction.MENU_ACTIVATE,
        text        = g_i18n:getText("ui_btn_storages"),
        callback    = function() self:onClickStorages() end,
        disabled    = true,
    }
    self.sellPointButtonInfo = {
        inputAction = InputAction.MENU_CANCEL,
        text        = g_i18n:getText("ui_btn_sellpoints"),
        callback    = function() self:onClickSellPoints() end,
        disabled    = true,
    }
    self.toggleAnimalsButtonInfo = {
        inputAction = InputAction.MENU_PAGE_NEXT,
        text        = g_i18n:getText("ui_btn_hide_animals"),
        callback    = function() self:onClickToggleAnimals() end,
        disabled    = false,
    }
    self:setMenuButtonInfo({
        { inputAction = InputAction.MENU_BACK },
        self.configAlertButtonInfo,
        self.tagButtonInfo,
        self.storageButtonInfo,
        self.sellPointButtonInfo,
        self.toggleAnimalsButtonInfo,
    })
    return self
end

function PriceAlertFrame:onGuiSetupFinished()
    PriceAlertFrame:superClass().onGuiSetupFinished(self)
    self.txtBalanceCurrent   = self:getDescendantById("txtBalanceCurrent")
    self.txtBalancePotential = self:getDescendantById("txtBalancePotential")
    self.balanceBg           = self:getDescendantById("balanceBg")
    self.balancePanel        = self:getDescendantById("balancePanel")
    self.footerTotalNow1     = self:getDescendantById("footerTotalNow1")
    self.footerTotalMax1     = self:getDescendantById("footerTotalMax1")
    self.footerTotalNow2     = self:getDescendantById("footerTotalNow2")
    self.footerTotalMax2     = self:getDescendantById("footerTotalMax2")
    self.footerTotals1       = self:getDescendantById("footerTotals1")
    self.footerTotals2       = self:getDescendantById("footerTotals2")
    self.hdrProduct3         = self:getDescendantById("hdrProduct3")
    self.hdrQty3             = self:getDescendantById("hdrQty3")
    self.hdrPct3             = self:getDescendantById("hdrPct3")
    self.hdrMinQty3          = self:getDescendantById("hdrMinQty3")
    self.hdrStopTs3          = self:getDescendantById("hdrStopTs3")
    self.hdrBell3            = self:getDescendantById("hdrBell3")
    if self.priceTable ~= nil then
        self.priceTable:setDataSource(self)
        self.priceTable:setDelegate(self)
        self.priceTable.onSelectionChanged = function(list, section, index) self:onListSelectionChanged(list, section, index) end
    end
    if self.priceTableAlert ~= nil then
        self.priceTableAlert:setDataSource(self)
        self.priceTableAlert:setDelegate(self)
        self.priceTableAlert.onSelectionChanged = function(list, section, index) self:onListSelectionChanged(list, section, index) end
    end
    if self.priceTableConfig ~= nil then
        self.priceTableConfig:setDataSource(self)
        self.priceTableConfig:setDelegate(self)
        self.priceTableConfig.onSelectionChanged = function(list, section, index) self:onListSelectionChanged(list, section, index) end
    end
    if self.priceTableUnsellable ~= nil then
        self.priceTableUnsellable:setDataSource(self)
        self.priceTableUnsellable:setDelegate(self)
        self.priceTableUnsellable.onSelectionChanged = function(list, section, index) self:onListSelectionChanged(list, section, index) end
    end
end

function PriceAlertFrame:initialize()
    self.selectorPrefab:unlinkElement()
    FocusManager:removeElement(self.selectorPrefab)
    for i = 1, PriceAlertFrame.NUM_TABS do
        self.subCategoryPaging:addText(tostring(i))
        self.subCategoryTabs[i] = self.selectorPrefab:clone(self.subCategoryBox)
        FocusManager:loadElementFromCustomValues(self.subCategoryTabs[i])
        self.subCategoryTabs[i]:setText(g_i18n:getText(PriceAlertFrame.TAB_NAMES[i]))
        self.subCategoryTabs[i]:getDescendantByName("background"):setSize(
            self.subCategoryTabs[i].size[1], self.subCategoryTabs[i].size[2])
        local tabIndex = i
        self.subCategoryTabs[i].onClickCallback = function() self:switchTab(tabIndex) end
    end
    self.subCategoryBox:invalidateLayout()
    self.subCategoryPaging:setSize(self.subCategoryBox.maxFlowSize + 140 * g_pixelSizeScaledX)
end

function PriceAlertFrame:onFrameOpen()
    PriceAlertFrame:superClass().onFrameOpen(self)
    self:collectData()
    self:switchTab(PriceAlertFrame.TAB_ALL)
end

function PriceAlertFrame:switchTab(tabIndex)
    self.currentTab = tabIndex
    local c1=self["tabContainer1"]; local c2=self["tabContainer2"]; local c3=self["tabContainer3"]; local c4=self["tabContainer4"]
    if c1~=nil then c1:setVisible(tabIndex==1) end
    if c2~=nil then c2:setVisible(tabIndex==2) end
    if c3~=nil then c3:setVisible(tabIndex==3) end
    if c4~=nil then c4:setVisible(tabIndex==4) end
    for i = 1, PriceAlertFrame.NUM_TABS do
        if self.subCategoryTabs[i]~=nil then self.subCategoryTabs[i]:setSelected(i==tabIndex) end
    end
    if tabIndex == 1 then
        self:applySort(tabIndex)
        self:updateSortIndicators()
        if self.priceTable~=nil then self.priceTable:reloadData(); FocusManager:setFocus(self.priceTable) end
        self:updateBalanceDisplay()
    elseif tabIndex == 2 then
        self:applySort(tabIndex)
        self:updateSortIndicators()
        if self.priceTableAlert~=nil then self.priceTableAlert:reloadData(); FocusManager:setFocus(self.priceTableAlert) end
        self:updateBalanceDisplay()
    elseif tabIndex == 3 then
        self:applySort(tabIndex)
        self:updateSortIndicators()
        if self.priceTableUnsellable~=nil then self.priceTableUnsellable:reloadData(); FocusManager:setFocus(self.priceTableUnsellable) end
    elseif tabIndex == 4 then
        self:applySortTabConfig()
        if self.priceTableConfig~=nil then self.priceTableConfig:reloadData(); FocusManager:setFocus(self.priceTableConfig) end
    end
end

function PriceAlertFrame:onClickTab(state) self:switchTab(state) end

function PriceAlertFrame:onFrameClose()
    PriceAlertFrame:superClass().onFrameClose(self)
    self.rows={}; self.allRows={}; self.allSellableRows={}; self.selectedRow=nil
end

function PriceAlertFrame:onListSelectionChanged(list, section, index)
    if list == self.priceTableConfig then
        if index >= 1 and index <= #self.allSellableRows then
            self.selectedRow = self.allSellableRows[index]
        else self.selectedRow = nil end
    else
        if index >= 1 and index <= #self.rows then
            self.selectedRow = self.rows[index]
        else self.selectedRow = nil end
    end
    self:updateButtons()
end

function PriceAlertFrame:updateButtons()
    local row = self.selectedRow
    local hasHotspot = row ~= nil and row.bestHotspot ~= nil
    self.tagButtonInfo.disabled = not hasHotspot
    if hasHotspot and row.bestHotspot == g_currentMission.currentMapTargetHotspot then
        self.tagButtonInfo.text = g_i18n:getText("ui_storage_btnUnmark")
    else
        self.tagButtonInfo.text = g_i18n:getText("ui_storage_btnMark")
    end
    local canConfig = row ~= nil and not row.noSellPoint
    self.configAlertButtonInfo.disabled = not canConfig
    local hasStock = row ~= nil and row.qty > 0
    self.storageButtonInfo.disabled = not hasStock
    if row ~= nil and row.isAnimal then
        self.storageButtonInfo.text = g_i18n:getText("ui_btn_enclosures")
    else
        self.storageButtonInfo.text = g_i18n:getText("ui_btn_storages")
    end
    local hasSellPoint = row ~= nil and not row.noSellPoint
    self.sellPointButtonInfo.disabled = not hasSellPoint
    self.toggleAnimalsButtonInfo.text = g_i18n:getText(
        PriceAlertFrame.showAnimals and "ui_btn_hide_animals" or "ui_btn_show_animals")
    self.toggleAnimalsButtonInfo.disabled = (self.currentTab == PriceAlertFrame.TAB_CONFIG or self.currentTab == PriceAlertFrame.TAB_UNSELLABLE)
    self:setMenuButtonInfoDirty()
end

function PriceAlertFrame:updateBalanceDisplay()
    local isTab3 = self.currentTab == PriceAlertFrame.TAB_CONFIG or self.currentTab == PriceAlertFrame.TAB_UNSELLABLE
    if self.balanceBg    then self.balanceBg:setVisible(not isTab3) end
    if self.balancePanel then self.balancePanel:setVisible(not isTab3) end
    if self.footerTotals1 then self.footerTotals1:setVisible(self.currentTab == 1) end
    if self.footerTotals2 then self.footerTotals2:setVisible(self.currentTab == 2) end
    if isTab3 then return end
    local farmId = g_currentMission:getFarmId()
    local currentBalance = g_currentMission:getMoney(farmId) or 0
    local sumTotalNow = 0
    local sumTotalMax = 0
    for _, row in ipairs(self.rows) do
        if row.totalNow and row.totalNow > 0 then sumTotalNow = sumTotalNow + row.totalNow end
        if row.totalMax and row.totalMax > 0 then sumTotalMax = sumTotalMax + row.totalMax end
    end
    local potentialBalance = currentBalance + sumTotalMax
    if self.txtBalanceCurrent   then self.txtBalanceCurrent:setText(g_i18n:formatMoney(currentBalance, 0, true, true)) end
    if self.txtBalancePotential then self.txtBalancePotential:setText(g_i18n:formatMoney(potentialBalance, 0, true, true)) end
    local fmtNow = sumTotalNow > 0 and g_i18n:formatMoney(sumTotalNow, 0, true, true) or "-"
    local fmtMax = sumTotalMax > 0 and g_i18n:formatMoney(sumTotalMax, 0, true, true) or "-"
    if self.footerTotalNow1 then self.footerTotalNow1:setText(fmtNow) end
    if self.footerTotalMax1 then self.footerTotalMax1:setText(fmtMax) end
    if self.footerTotalNow2 then self.footerTotalNow2:setText(fmtNow) end
    if self.footerTotalMax2 then self.footerTotalMax2:setText(fmtMax) end
end

-- === INDICATORI ORDINAMENTO TAB 1+2 ===

local COL_TO_ICONS = {
    product  = { asc="iconProductAsc",   desc="iconProductDesc",   asc2="iconProductAsc2",   desc2="iconProductDesc2"   },
    qty      = { asc="iconQtyAsc",       desc="iconQtyDesc",       asc2="iconQtyAsc2",       desc2="iconQtyDesc2"       },
    nowPrice = { asc="iconNowPriceAsc",  desc="iconNowPriceDesc",  asc2="iconNowPriceAsc2",  desc2="iconNowPriceDesc2"  },
    totalNow = { asc="iconTotalNowAsc",  desc="iconTotalNowDesc",  asc2="iconTotalNowAsc2",  desc2="iconTotalNowDesc2"  },
    maxPrice = { asc="iconMaxPriceAsc",  desc="iconMaxPriceDesc",  asc2="iconMaxPriceAsc2",  desc2="iconMaxPriceDesc2"  },
    bestMonth= { asc="iconBestMonthAsc", desc="iconBestMonthDesc", asc2="iconBestMonthAsc2", desc2="iconBestMonthDesc2" },
    totalMax = { asc="iconTotalMaxAsc",  desc="iconTotalMaxDesc",  asc2="iconTotalMaxAsc2",  desc2="iconTotalMaxDesc2"  },
    pricePct = { asc="iconPricePctAsc",  desc="iconPricePctDesc",  asc2="iconPricePctAsc2",  desc2="iconPricePctDesc2"  },
    alert    = { asc="iconAlertAsc",     desc="iconAlertDesc",     asc2="iconAlertAsc2",     desc2="iconAlertDesc2"     },
}
local COL_TO_HDR = {
    product="hdrProduct", qty="hdrQty", nowPrice="hdrNowPrice",
    totalNow="hdrTotalNow", maxPrice="hdrMaxPrice", bestMonth="hdrBestMonth",
    totalMax="hdrTotalMax", pricePct="hdrPricePct", alert="hdrAlert",
}

function PriceAlertFrame:updateSortIndicators()
    local col = PriceAlertFrame.sortColumn
    local asc = PriceAlertFrame.sortAsc
    for _, hdrId in pairs(COL_TO_HDR) do
        local e=self[hdrId]; if e~=nil then e.textColor={1,1,1,0.5} end
    end
    for _, icons in pairs(COL_TO_ICONS) do
        local a=self[icons.asc];   if a~=nil then a:setVisible(false) end
        local d=self[icons.desc];  if d~=nil then d:setVisible(false) end
        local a2=self[icons.asc2]; if a2~=nil then a2:setVisible(false) end
        local d2=self[icons.desc2];if d2~=nil then d2:setVisible(false) end
    end
    local hdrId=COL_TO_HDR[col]
    if hdrId and self[hdrId] then self[hdrId].textColor={1,1,1,1} end
    local icons=COL_TO_ICONS[col]
    if icons then
        local a=self[icons.asc];   if a~=nil then a:setVisible(asc) end
        local d=self[icons.desc];  if d~=nil then d:setVisible(not asc) end
        local a2=self[icons.asc2]; if a2~=nil then a2:setVisible(asc) end
        local d2=self[icons.desc2];if d2~=nil then d2:setVisible(not asc) end
    end
end

-- === INDICATORI ORDINAMENTO TAB 3 ===

local COL3_TO_ICONS = {
    product = { asc="iconProductAsc3", desc="iconProductDesc3" },
    qty     = { asc="iconQtyAsc3",     desc="iconQtyDesc3"     },
    pct     = { asc="iconPctAsc3",     desc="iconPctDesc3"     },
    minqty  = { asc="iconMinQtyAsc3",  desc="iconMinQtyDesc3"  },
    stopts  = { asc="iconStopTsAsc3",  desc="iconStopTsDesc3"  },
    bell    = { asc="iconBellAsc3",    desc="iconBellDesc3"    },
}

function PriceAlertFrame:updateSortIndicatorsConfig()
    local col = self.sortColumnConfig
    local asc = self.sortAscConfig
    -- Nascondi tutte le icone e resetta colore intestazioni
    for _, icons in pairs(COL3_TO_ICONS) do
        local a=self[icons.asc];  if a~=nil then a:setVisible(false) end
        local d=self[icons.desc]; if d~=nil then d:setVisible(false) end
    end
    local hdrs = {
        { key="product", el=self.hdrProduct3 },
        { key="qty",     el=self.hdrQty3     },
        { key="pct",     el=self.hdrPct3     },
        { key="minqty",  el=self.hdrMinQty3  },
        { key="stopts",  el=self.hdrStopTs3  },
        { key="bell",    el=self.hdrBell3    },
    }
    for _, h in ipairs(hdrs) do
        if h.el ~= nil then
            h.el.textColor = (h.key == col) and {1,1,1,1} or {1,1,1,0.5}
        end
    end
    -- Mostra icona corretta sulla colonna attiva
    local icons = COL3_TO_ICONS[col]
    if icons then
        local a=self[icons.asc];  if a~=nil then a:setVisible(asc) end
        local d=self[icons.desc]; if d~=nil then d:setVisible(not asc) end
    end
end

-- === FORMATTAZIONE ===

local function fmtQty(qty, unitShort)
    if not qty or qty <= 0 then return "-" end
    local unit = unitShort or "L"
    local s = string.format("%d", math.floor(qty))
    local result = ""
    for i = 1, #s do
        if i > 1 and (#s - i + 1) % 3 == 0 then result = result .. "." end
        result = result .. s:sub(i, i)
    end
    return result .. " " .. unit
end

local function fmtNum(n)
    if not n or n <= 0 then return "-" end
    local s = string.format("%d", math.floor(n))
    local result = ""
    for i = 1, #s do
        if i > 1 and (#s - i + 1) % 3 == 0 then result = result .. "." end
        result = result .. s:sub(i, i)
    end
    return result
end

-- === RACCOLTA DATI ===

local function addStock(sd, ftIdx, level)
    if ftIdx and level and level > 0 and sd[ftIdx] then
        sd[ftIdx].qty = sd[ftIdx].qty + level
    end
end

-- === getBestHotspot(ftName) ===
-- Restituisce il miglior hotspot per un prodotto o animale, o nil se non trovato.
-- Per prodotti/balle/pallet: cerca la stazione vendita con prezzo migliore.
-- Per animali: cerca silenziosamente il mercante di bestiame per nome tradotto.

function PriceAlertFrame.getBestHotspot(ftName)
    local farmId = g_currentMission:getFarmId()

    if string.sub(ftName, 1, 7) == "animal_" then
        -- Animali: cerca hotspot il cui nome corrisponde alla traduzione di animals_dealer
        local dealerName = g_i18n:getText("animals_dealer")
        if dealerName ~= nil then
            for _, placeable in ipairs(g_currentMission.placeableSystem.placeables) do
                if placeable.spec_hotspots ~= nil then
                    for _, hs in ipairs(placeable.spec_hotspots.mapHotspots or {}) do
                        if hs.name ~= nil and hs.name == dealerName then
                            return hs
                        end
                    end
                end
            end
        end
        return nil
    else
        -- Prodotti, balle e pallet: cerca stazione vendita con prezzo migliore
        local ft = g_fillTypeManager:getFillTypeByName(ftName)
        if ft == nil then return nil end
        local ftIdx = ft.index
        local bestPrice = 0
        local bestHotspot = nil
        for _, station in pairs(g_currentMission.storageSystem:getUnloadingStations()) do
            if station:isa(SellingStation) and not station.hideFromPricesMenu and station.ownerFarmId ~= farmId then
                if station.acceptedFillTypes[ftIdx] then
                    local price = station:getEffectiveFillTypePrice(ftIdx)
                    if price and price > bestPrice then
                        bestPrice = price
                        local hs = nil
                        if station.owningPlaceable ~= nil and station.owningPlaceable.spec_hotspots ~= nil then
                            for _, h in ipairs(station.owningPlaceable.spec_hotspots.mapHotspots or {}) do
                                if h.worldX ~= nil then hs = h; break end
                            end
                        end
                        bestHotspot = hs
                    end
                end
            end
        end
        return bestHotspot
    end
end

-- === getBestMonth(ftName) ===
-- Restituisce il periodo stagionale con prezzo massimo per un fillType.
-- Solo per prodotti normali, balle e pallet. Per animali non va chiamata.

function PriceAlertFrame.getBestMonth(ftName)
    local ft = g_fillTypeManager:getFillTypeByName(ftName)
    if ft == nil then return SeasonPeriod.EARLY_SPRING end
    local bestMonth = SeasonPeriod.EARLY_SPRING
    local maxPrice = 0
    if ft.economy and ft.economy.factors then
        for period = SeasonPeriod.EARLY_SPRING, SeasonPeriod.LATE_WINTER do
            local p = (ft.pricePerLiter or 0) * (ft.economy.factors[period] or 1)
            if p > maxPrice then maxPrice = p; bestMonth = period end
        end
    end
    return bestMonth
end

-- === RACCOLTA DATI GREZZI (usata da onHourChanged e da collectData) ===
-- Restituisce { [ftName] = { qty=..., pricePct=... } } per prodotti e animali

function PriceAlertFrame.collectRawData()
    local farmId = g_currentMission:getFarmId()
    local mult   = EconomyManager.getPriceMultiplier()
    local sd     = {}

    -- Inizializza tutti i fillType con indice numerico
    for _, ft in pairs(g_fillTypeManager.fillTypes) do
        local maxPrice = 0
        if ft.economy and ft.economy.factors then
            for period = SeasonPeriod.EARLY_SPRING, SeasonPeriod.LATE_WINTER do
                local p = (ft.pricePerLiter or 0) * (ft.economy.factors[period] or 1) * mult
                if p > maxPrice then maxPrice = p end
            end
        else
            maxPrice = (ft.pricePerLiter or 0) * mult
        end
        sd[ft.index] = { index = ft.index, name = ft.name, qty = 0, bestPrice = 0, maxPrice = maxPrice, noSellPoint = true }
    end

    -- Prezzi dai punti vendita
    for _, station in pairs(g_currentMission.storageSystem:getUnloadingStations()) do
        if station:isa(SellingStation) and not station.hideFromPricesMenu and station.ownerFarmId ~= farmId then
            for ftIdx, isAccepted in pairs(station.acceptedFillTypes) do
                if isAccepted and sd[ftIdx] then
                    local price = station:getEffectiveFillTypePrice(ftIdx)
                    if price and price > 0 then
                        sd[ftIdx].noSellPoint = false
                        if price > sd[ftIdx].bestPrice then sd[ftIdx].bestPrice = price end
                    end
                end
            end
        end
    end

    -- Stock da placeables
    local uniqueIDs = {}
    for _, placeable in ipairs(g_currentMission.placeableSystem.placeables) do
        local owned = placeable.ownerFarmId == farmId or placeable.ownerFarmId == 0

        if placeable.spec_silo ~= nil and owned then
            for _, storage in ipairs(placeable.spec_silo.storages) do
                if storage.ownerFarmId == farmId then
                    for ftIdx, level in pairs(storage.fillLevels) do addStock(sd, ftIdx, level) end
                end
            end
        end
        if placeable.spec_siloExtension ~= nil and owned then
            local s = placeable.spec_siloExtension.storage
            if s and s.ownerFarmId == farmId then
                for ftIdx, level in pairs(s.fillLevels) do addStock(sd, ftIdx, level) end
            end
        end
        if placeable.spec_husbandry ~= nil and placeable.ownerFarmId == farmId and placeable.spec_husbandry.storage ~= nil then
            for ftIdx, level in pairs(placeable.spec_husbandry.storage.fillLevels) do
                if placeable.spec_husbandry.loadingStation ~= nil and placeable.spec_husbandry.loadingStation.supportedFillTypes[ftIdx] then
                    addStock(sd, ftIdx, level)
                end
            end
        end
        if placeable.spec_beehivePalletSpawner ~= nil and placeable.ownerFarmId == farmId then
            addStock(sd, placeable.spec_beehivePalletSpawner.fillType, placeable.spec_beehivePalletSpawner.pendingLiters)
        end
        if placeable.spec_manureHeap ~= nil and placeable.ownerFarmId == farmId and placeable.spec_manureHeap.manureHeap ~= nil then
            for ftIdx, level in pairs(placeable.spec_manureHeap.manureHeap.fillLevels) do addStock(sd, ftIdx, level) end
        end
        if placeable.spec_bunkerSilo ~= nil and placeable.ownerFarmId == farmId and placeable.spec_bunkerSilo.bunkerSilo ~= nil then
            local bs = placeable.spec_bunkerSilo.bunkerSilo
            if bs.state == BunkerSilo.STATE_FILL or bs.state == BunkerSilo.STATE_CLOSED then
                if bs.inputFillType and bs.inputFillType ~= FillType.UNKNOWN then addStock(sd, bs.inputFillType, bs.fillLevel) end
            elseif bs.state == BunkerSilo.STATE_DRAIN or bs.state == BunkerSilo.STATE_FERMENTED then
                addStock(sd, bs.outputFillType, bs.fillLevel)
            end
        end
        if placeable.spec_objectStorage ~= nil and placeable.spec_objectStorage.objectInfos ~= nil and placeable.ownerFarmId == farmId then
            for _, info in ipairs(placeable.spec_objectStorage.objectInfos) do
                if #info.objects == 1 and info.numObjects ~= 1 then
                    local ftIdx, level = 0, 0
                    if info.objects[1].baleAttributes then ftIdx = info.objects[1].baleAttributes.fillType; level = info.objects[1].baleAttributes.fillLevel * info.numObjects
                    elseif info.objects[1].baleObject then ftIdx = info.objects[1].baleObject.fillType; level = info.objects[1].baleObject.fillLevel * info.numObjects
                    elseif info.objects[1].palletAttributes then ftIdx = info.objects[1].palletAttributes.fillType; level = info.objects[1].palletAttributes.fillLevel * info.numObjects end
                    addStock(sd, ftIdx, level)
                else
                    for _, obj in ipairs(info.objects) do
                        local ftIdx, level, uid = 0, 0, nil
                        if obj.baleAttributes and obj.baleAttributes.farmId == farmId then ftIdx = obj.baleAttributes.fillType; level = obj.baleAttributes.fillLevel; uid = obj.baleAttributes.uniqueId
                        elseif obj.baleObject and obj.baleObject.ownerFarmId == farmId then ftIdx = obj.baleObject.fillType; level = obj.baleObject.fillLevel; uid = obj.baleObject.uniqueId
                        elseif obj.palletAttributes and obj.palletAttributes.ownerFarmId == farmId then ftIdx = obj.palletAttributes.fillType; level = obj.palletAttributes.fillLevel end
                        local seen = false
                        if uid then for _, v in ipairs(uniqueIDs) do if v == uid then seen = true; break end end end
                        if not seen then addStock(sd, ftIdx, level); if uid then table.insert(uniqueIDs, uid) end end
                    end
                end
            end
        end
    end

    -- Produzioni
    if g_currentMission.productionChainManager then
        for _, prod in ipairs(g_currentMission.productionChainManager.productionPoints) do
            if prod:getOwnerFarmId() == farmId then
                for _, ftIdx in ipairs(prod.outputFillTypeIdsArray) do
                    addStock(sd, ftIdx, prod.storage:getFillLevel(ftIdx))
                end
            end
        end
    end

    -- Pallet veicoli e veicoli/rimorchi
    if g_currentMission.vehicleSystem then
        for _, vehicle in ipairs(g_currentMission.vehicleSystem.vehicles) do
            if vehicle.ownerFarmId == farmId then
                if vehicle.isPallet and vehicle.spec_fillUnit ~= nil and #vehicle.spec_fillUnit.fillUnits > 0 then
                    local fu = vehicle.spec_fillUnit.fillUnits[1]
                    addStock(sd, fu.fillType, fu.fillLevel)
                elseif not vehicle.isPallet and vehicle.getFillUnits ~= nil then
                    local fillUnits = vehicle:getFillUnits()
                    if fillUnits ~= nil then
                        for i, _ in ipairs(fillUnits) do
                            local fillType  = vehicle:getFillUnitFillType(i)
                            local fillLevel = vehicle:getFillUnitFillLevel(i)
                            if fillType ~= nil and fillType ~= FillType.UNKNOWN and fillLevel > 0 then
                                addStock(sd, fillType, fillLevel)
                            end
                        end
                    end
                end
            end
        end
    end

    -- Balle e pallet liberi nel mondo (itemSystem) — mancava in onHourChanged!
    if g_currentMission.itemSystem then
        for _, item in pairs(g_currentMission.itemSystem.itemsToSave) do
            local bale = item.item
            if bale.isa ~= nil and bale:isa(Bale) and bale.ownerFarmId == farmId then
                local seen = false
                if bale.uniqueId then for _, v in ipairs(uniqueIDs) do if v == bale.uniqueId then seen = true; break end end end
                if not seen and bale.fillType ~= FillType.UNKNOWN and bale.fillLevel > 0 then
                    addStock(sd, bale.fillType, bale.fillLevel)
                    if bale.uniqueId then table.insert(uniqueIDs, bale.uniqueId) end
                end
            end
        end
    end

    -- Costruisce risultato finale: { [ftName] = { qty=..., pricePct=..., + campi UI } }
    local result = {}
    for _, data in pairs(sd) do
        local pricePct = 0
        if data.maxPrice > 0 and data.bestPrice > 0 then
            pricePct = math.floor((data.bestPrice / data.maxPrice) * 1000) / 10
        end
        local ft = g_fillTypeManager:getFillTypeByIndex(data.index)
        result[data.name] = {
            qty         = data.qty,
            pricePct    = pricePct,
            title       = ft and (ft.title or ft.name) or data.name,
            unitShort   = ft and ft.unitShort or "L",
            hudOverlay  = ft and ft.hudOverlayFilename or "",
            maxPrice    = data.maxPrice,
            bestPrice   = data.bestPrice,
            noSellPoint = data.noSellPoint,
            isAnimal    = false,
        }
    end

    -- Animali
    local animalsByPlaceable = {}  -- [placeable] = { [subTypeName] = { maxPricePct=..., qty=... } }
    local horseClusterIndex = 0
    if g_currentMission.animalSystem ~= nil then
        for _, placeable in ipairs(g_currentMission.placeableSystem.placeables) do
            if placeable.spec_husbandryAnimals ~= nil and placeable.ownerFarmId == farmId then
                local spec = placeable.spec_husbandryAnimals
                if spec.clusterSystem ~= nil then
                    for _, cluster in ipairs(spec.clusterSystem:getClusters()) do
                        local subTypeIdx = cluster:getSubTypeIndex()
                        local subType    = g_currentMission.animalSystem:getSubTypeByIndex(subTypeIdx)
                        if subType ~= nil then
                            local numAnimals = cluster.numAnimals or 0
                            local isHorse = string.find(string.upper(subType.name), "HORSE") ~= nil
                            local ft = g_fillTypeManager:getFillTypeByName(subType.name)

                            if isHorse then
                                -- Cavalli: una entry per cluster, prezzo da getSellPrice()
                                horseClusterIndex = horseClusterIndex + 1
                                local ftName = "animal_" .. subType.name .. "_h" .. horseClusterIndex
                                local sellPrice = 0
                                if type(cluster.getSellPrice) == "function" then
                                    local ok, sp = pcall(function() return cluster:getSellPrice() end)
                                    if ok and type(sp) == "number" and sp > 0 then sellPrice = sp end
                                end
                                local maxPriceAnimal = 0
                                if subType.sellPrice and type(subType.sellPrice.get) == "function" then
                                    for testAge = 0, 120 do
                                        local okM, p = pcall(function() return subType.sellPrice:get(testAge) end)
                                        if okM and type(p) == "number" and p > maxPriceAnimal then maxPriceAnimal = p end
                                    end
                                end
                                local pricePct = 0
                                if maxPriceAnimal > 0 and sellPrice > 0 then
                                    pricePct = math.floor((sellPrice / maxPriceAnimal) * 1000) / 10
                                end
                                result[ftName] = {
                                    qty               = numAnimals,
                                    pricePct          = pricePct,
                                    title             = ft and (ft.title or ft.name) or subType.name,
                                    hudOverlay        = ft and ft.hudOverlayFilename or "",
                                    maxPrice          = maxPriceAnimal,
                                    bestPrice         = sellPrice,
                                    noSellPoint       = false,
                                    isAnimal          = true,
                                    isHorse           = true,
                                    animalSubTypeName = subType.name,
                                    animalAge         = cluster.age or 0,
                                    animalHealth      = cluster.health or 0,
                                    horseSellPrice    = sellPrice,
                                }
                                -- Popola animalsByPlaceable per cavalli
                                if animalsByPlaceable[placeable] == nil then animalsByPlaceable[placeable] = {} end
                                local abp = animalsByPlaceable[placeable][subType.name]
                                if abp == nil then
                                    animalsByPlaceable[placeable][subType.name] = { maxPricePct = pricePct, qty = numAnimals }
                                else
                                    if pricePct > abp.maxPricePct then abp.maxPricePct = pricePct end
                                    abp.qty = abp.qty + numAnimals
                                end
                            else
                                -- Altri animali: logica esistente aggregata per razza
                                local ftName = "animal_" .. subType.name
                                local age = cluster.age or 0
                                if type(cluster.getAge) == "function" then
                                    local ok, a = pcall(function() return cluster:getAge() end)
                                    if ok and type(a) == "number" then age = a end
                                end
                                local health = cluster.health or 0
                                local rawPrice = 0
                                if subType.sellPrice and type(subType.sellPrice.get) == "function" then
                                    local ok2, sp = pcall(function() return subType.sellPrice:get(age) end)
                                    if ok2 and type(sp) == "number" and sp > 0 then rawPrice = sp end
                                end
                                local healthMin = 2 * (subType.healthThresholdFactor or 0.2)
                                local healthFactor = healthMin + (1 - healthMin) * (health / 100)
                                local pricePerHead = math.floor(rawPrice * healthFactor + 0.5)
                                local maxPriceAnimal = 0
                                if subType.sellPrice and type(subType.sellPrice.get) == "function" then
                                    for testAge = 0, 120 do
                                        local okM, p = pcall(function() return subType.sellPrice:get(testAge) end)
                                        if okM and type(p) == "number" and p > maxPriceAnimal then maxPriceAnimal = p end
                                    end
                                end
                                local pricePct = 0
                                if maxPriceAnimal > 0 then pricePct = math.floor((pricePerHead / maxPriceAnimal) * 1000) / 10 end
                                if result[ftName] == nil then
                                    result[ftName] = {
                                        qty               = 0,
                                        pricePct          = pricePct,
                                        title             = ft and (ft.title or ft.name) or subType.name,
                                        hudOverlay        = ft and ft.hudOverlayFilename or "",
                                        maxPrice          = maxPriceAnimal,
                                        bestPrice         = pricePerHead,
                                        noSellPoint       = false,
                                        isAnimal          = true,
                                        isHorse           = false,
                                        animalSubTypeName = subType.name,
                                        animalAge         = age,
                                        animalHealth      = health,
                                    }
                                end
                                result[ftName].qty = result[ftName].qty + numAnimals
                                -- Popola animalsByPlaceable per altri animali
                                if animalsByPlaceable[placeable] == nil then animalsByPlaceable[placeable] = {} end
                                local abp = animalsByPlaceable[placeable][subType.name]
                                if abp == nil then
                                    animalsByPlaceable[placeable][subType.name] = { maxPricePct = pricePct, qty = numAnimals }
                                else
                                    if pricePct > abp.maxPricePct then abp.maxPricePct = pricePct end
                                    abp.qty = abp.qty + numAnimals
                                end
                            end
                        end
                    end
                end
            end
        end
    end

    return result, animalsByPlaceable
end

function PriceAlertFrame:collectData()
    self.allRows = {}
    self.allSellableRows = {}
    local farmId = g_currentMission:getFarmId()
    local currentPeriod = g_currentMission.environment.currentPeriod

    -- Raccoglie tutti i dati grezzi tramite la funzione condivisa
    local rawData, _ = PriceAlertFrame.collectRawData()

    -- === PRODOTTI, BALLE E PALLET ===
    for ftName, data in pairs(rawData) do
        if not data.isAnimal and data.qty > 0 then
            local ft = g_fillTypeManager:getFillTypeByName(ftName)
            if data.noSellPoint then
                -- Prodotti non vendibili: inseriti in allRows con noSellPoint=true
                table.insert(self.allRows, {
                    title          = data.title,
                    ftName         = ftName,
                    ftIndex        = ft and ft.index or 0,
                    hudOverlay     = data.hudOverlay,
                    noSellPoint    = true,
                    bestHotspot    = nil,
                    qty            = data.qty,
                    qtyStr         = fmtQty(data.qty, data.unitShort),
                    bestStation    = "-",
                    nowPrice       = 0,
                    priceStr       = "-",
                    totalNow       = 0,
                    totalStr       = "-",
                    maxPrice       = 0,
                    maxStr         = "-",
                    bestMonth      = 0,
                    bestMonthStr   = "-",
                    isCurrentMonth = false,
                    totalMax       = 0,
                    totalMaxStr    = "-",
                    pricePct       = 0,
                    pctStr         = "-",
                    isAnimal       = false,
                })
            else
                local bestHotspot = PriceAlertFrame.getBestHotspot(ftName)
                local bestMonth   = PriceAlertFrame.getBestMonth(ftName)
                local bestStation = "-"
                if ft ~= nil then
                    for _, station in pairs(g_currentMission.storageSystem:getUnloadingStations()) do
                        if station:isa(SellingStation) and not station.hideFromPricesMenu and station.ownerFarmId ~= farmId then
                            if station.acceptedFillTypes[ft.index] then
                                local price = station:getEffectiveFillTypePrice(ft.index)
                                if price and price == data.bestPrice then
                                    bestStation = station:getName() or "-"
                                    break
                                end
                            end
                        end
                    end
                end
                local priceStr, totalStr, maxStr, totalMaxStr, pctStr = "-", "-", "-", "-", "-"
                local totalNow, totalMax = 0, 0
                if data.bestPrice > 0 then
                    priceStr = g_i18n:formatMoney(data.bestPrice * 1000, 0, true, true)
                    totalNow = data.bestPrice * data.qty
                    totalStr = g_i18n:formatMoney(totalNow, 0, true, true)
                end
                if data.maxPrice > 0 then
                    maxStr      = g_i18n:formatMoney(data.maxPrice * 1000, 0, true, true)
                    totalMax    = data.maxPrice * data.qty
                    totalMaxStr = g_i18n:formatMoney(totalMax, 0, true, true)
                    if data.bestPrice > 0 then pctStr = string.format("%.1f%%", data.pricePct) end
                end
                table.insert(self.allRows, {
                    title          = data.title,
                    ftName         = ftName,
                    ftIndex        = ft and ft.index or 0,
                    hudOverlay     = data.hudOverlay,
                    noSellPoint    = false,
                    bestHotspot    = bestHotspot,
                    qty            = data.qty,
                    qtyStr         = fmtQty(data.qty, data.unitShort),
                    bestStation    = bestStation,
                    nowPrice       = data.bestPrice,
                    priceStr       = priceStr,
                    totalNow       = totalNow,
                    totalStr       = totalStr,
                    maxPrice       = data.maxPrice,
                    maxStr         = maxStr,
                    bestMonth      = bestMonth,
                    bestMonthStr   = g_i18n:formatPeriod(bestMonth, true),
                    isCurrentMonth = bestMonth == currentPeriod,
                    totalMax       = totalMax,
                    totalMaxStr    = totalMaxStr,
                    pricePct       = data.pricePct,
                    pctStr         = pctStr,
                    isAnimal       = false,
                })
            end
        end
        -- allSellableRows per prodotti: solo quelli CON punto vendita (anche qty=0)
        if not data.isAnimal and not data.noSellPoint then
            local ft = g_fillTypeManager:getFillTypeByName(ftName)
            table.insert(self.allSellableRows, {
                title       = data.title,
                ftName      = ftName,
                ftIndex     = ft and ft.index or 0,
                hudOverlay  = data.hudOverlay,
                noSellPoint = false,
                bestHotspot = nil,
                qty         = data.qty,
                qtyStr      = fmtQty(data.qty, data.unitShort),
                pricePct    = data.pricePct,
                isAnimal    = false,
            })
        end
    end

    -- === ANIMALI: raggruppamento per razza + età + salute ===
    local animalDealerHotspot = PriceAlertFrame.getBestHotspot("animal_")
    local animalDealerName    = animalDealerHotspot ~= nil and g_i18n:getText("animals_dealer") or "-"
    print(string.format("[PriceAlert] animalDealer: name=%s hotspot=%s", tostring(animalDealerName), tostring(animalDealerHotspot ~= nil)))

    -- Raggruppa cluster per chiave:
    -- cavalli: razza + prezzo attuale (getSellPrice)
    -- altri animali: razza + età + salute
    local animalGroups = {}
    if g_currentMission.animalSystem ~= nil then
        for _, placeable in ipairs(g_currentMission.placeableSystem.placeables) do
            if placeable.spec_husbandryAnimals ~= nil and placeable.ownerFarmId == farmId then
                local spec = placeable.spec_husbandryAnimals
                if spec.clusterSystem ~= nil then
                    for _, cluster in ipairs(spec.clusterSystem:getClusters()) do
                        local subTypeIdx = cluster:getSubTypeIndex()
                        local numAnimals = cluster.numAnimals or 0
                        if numAnimals > 0 then
                            local subType = g_currentMission.animalSystem:getSubTypeByIndex(subTypeIdx)
                            if subType ~= nil then
                                local name = subType.name
                                local isHorse = string.find(string.upper(name), "HORSE") ~= nil
                                local ft = g_fillTypeManager:getFillTypeByName(name)
                                local key, pricePerHead, maxPriceAnimal, pricePct, age, health

                                if isHorse then
                                    -- Cavalli: prezzo da getSellPrice(), chiave per prezzo attuale
                                    local sellPrice = 0
                                    if type(cluster.getSellPrice) == "function" then
                                        local ok, sp = pcall(function() return cluster:getSellPrice() end)
                                        if ok and type(sp) == "number" and sp > 0 then sellPrice = sp end
                                    end
                                    pricePerHead = math.floor(sellPrice + 0.5)
                                    maxPriceAnimal = 0
                                    if subType.sellPrice and type(subType.sellPrice.get) == "function" then
                                        for testAge = 0, 120 do
                                            local okM, p = pcall(function() return subType.sellPrice:get(testAge) end)
                                            if okM and type(p) == "number" and p > maxPriceAnimal then maxPriceAnimal = p end
                                        end
                                    end
                                    pricePct = 0
                                    if maxPriceAnimal > 0 and pricePerHead > 0 then
                                        pricePct = math.floor((pricePerHead / maxPriceAnimal) * 1000) / 10
                                    end
                                    age = cluster.age or 0
                                    health = cluster.health or 0
                                    key = name .. "_horse_" .. tostring(pricePerHead)
                                else
                                    -- Altri animali: chiave razza+età+salute
                                    age = cluster.age or 0
                                    if type(cluster.getAge) == "function" then
                                        local ok, a = pcall(function() return cluster:getAge() end)
                                        if ok and type(a) == "number" then age = a end
                                    end
                                    health = cluster.health or 0
                                    local sellPriceBase = 0
                                    if subType.sellPrice and type(subType.sellPrice.get) == "function" then
                                        local ok2, sp = pcall(function() return subType.sellPrice:get(age) end)
                                        if ok2 and type(sp) == "number" and sp > 0 then sellPriceBase = sp end
                                    end
                                    if sellPriceBase == 0 then
                                        sellPriceBase = g_currentMission.animalSystem:getAnimalBuyPrice(subTypeIdx, age) or 0
                                    end
                                    local healthMin    = 2 * (subType.healthThresholdFactor or 0.2)
                                    local healthFactor = healthMin + (1 - healthMin) * (health / 100)
                                    pricePerHead = math.floor(sellPriceBase * healthFactor + 0.5)
                                    maxPriceAnimal = 0
                                    if subType.sellPrice and type(subType.sellPrice.get) == "function" then
                                        for testAge = 0, 120 do
                                            local okM, p = pcall(function() return subType.sellPrice:get(testAge) end)
                                            if okM and type(p) == "number" and p > maxPriceAnimal then maxPriceAnimal = p end
                                        end
                                    end
                                    pricePct = 0
                                    if maxPriceAnimal > 0 then pricePct = math.floor((pricePerHead / maxPriceAnimal) * 1000) / 10 end
                                    key = name .. "_" .. tostring(age) .. "_" .. tostring(health)
                                end

                                if animalGroups[key] == nil then
                                    animalGroups[key] = {
                                        name         = name,
                                        title        = ft and (ft.title or ft.name) or name,
                                        hudOverlay   = ft and ft.hudOverlayFilename or "",
                                        age          = age,
                                        health       = health,
                                        pricePerHead = pricePerHead,
                                        maxPrice     = maxPriceAnimal,
                                        pricePct     = pricePct,
                                        qty          = 0,
                                        isHorse      = isHorse,
                                    }
                                end
                                animalGroups[key].qty = animalGroups[key].qty + numAnimals
                            end
                        end
                    end
                end
            end
        end
    end

    -- Inserisce una riga per gruppo in allRows
    local monthsLabel = g_i18n:getText("pa_months") or "mesi"
    for _, g in pairs(animalGroups) do
        local totalNow = g.pricePerHead * g.qty
        local totalMax = g.maxPrice * g.qty
        local healthStr = string.format("%d%%", g.health)
        local titleWithAge = g.title .. " (" .. g.age .. " " .. monthsLabel .. ", " .. healthStr .. ")"
        table.insert(self.allRows, {
            title          = titleWithAge,
            ftName         = "animal_" .. g.name,
            ftIndex        = -1,
            hudOverlay     = g.hudOverlay,
            noSellPoint    = false,
            bestHotspot    = animalDealerHotspot,
            qty            = g.qty,
            qtyStr         = fmtNum(g.qty),
            bestStation    = animalDealerName,
            nowPrice       = g.pricePerHead,
            priceStr       = g.pricePerHead > 0 and g_i18n:formatMoney(g.pricePerHead, 0, true, true) or "-",
            totalNow       = totalNow,
            totalStr       = totalNow > 0 and g_i18n:formatMoney(totalNow, 0, true, true) or "-",
            maxPrice       = g.maxPrice,
            maxStr         = g.maxPrice > 0 and g_i18n:formatMoney(g.maxPrice, 0, true, true) or "-",
            bestMonth      = 0,
            bestMonthStr   = "-",
            isCurrentMonth = false,
            totalMax       = totalMax,
            totalMaxStr    = totalMax > 0 and g_i18n:formatMoney(totalMax, 0, true, true) or "-",
            pricePct       = g.pricePct,
            pctStr         = g.maxPrice > 0 and string.format("%.1f%%", g.pricePct) or "-",
            isAnimal       = true,
            animalSubType  = g.name,
            animalAge      = g.age,
        })
    end

    -- === allSellableRows per animali: una riga per razza, qty sommata ===
    local animalSellableByName = {}
    if g_currentMission.animalSystem ~= nil then
        for _, placeable in ipairs(g_currentMission.placeableSystem.placeables) do
            if placeable.spec_husbandryAnimals ~= nil and placeable.ownerFarmId == farmId then
                local spec = placeable.spec_husbandryAnimals
                if spec.clusterSystem ~= nil then
                    for _, cluster in ipairs(spec.clusterSystem:getClusters()) do
                        local subType2 = g_currentMission.animalSystem:getSubTypeByIndex(cluster:getSubTypeIndex())
                        if subType2 ~= nil then
                            local nm  = subType2.name
                            local ft2 = g_fillTypeManager:getFillTypeByName(nm)
                            if animalSellableByName[nm] == nil then
                                animalSellableByName[nm] = {
                                    title      = ft2 and ft2.title or nm,
                                    hudOverlay = ft2 and ft2.hudOverlayFilename or "",
                                    qty        = 0,
                                    pricePct   = 0,
                                }
                            end
                            animalSellableByName[nm].qty = animalSellableByName[nm].qty + (cluster.numAnimals or 0)
                        end
                    end
                end
            end
        end
        -- Aggiunge tutte le razze disponibili anche con qty=0
        for i = 1, 100 do
            local subType2 = g_currentMission.animalSystem:getSubTypeByIndex(i)
            if subType2 == nil then break end
            local nm = subType2.name
            if animalSellableByName[nm] == nil then
                local ft2 = g_fillTypeManager:getFillTypeByName(nm)
                animalSellableByName[nm] = {
                    title      = ft2 and ft2.title or nm,
                    hudOverlay = ft2 and ft2.hudOverlayFilename or "",
                    qty        = 0,
                    pricePct   = 0,
                }
            end
        end
        for nm, data in pairs(animalSellableByName) do
            table.insert(self.allSellableRows, {
                title       = data.title,
                ftName      = "animal_" .. nm,
                ftIndex     = -1,
                hudOverlay  = data.hudOverlay,
                noSellPoint = false,
                bestHotspot = animalDealerHotspot,
                qty         = data.qty,
                qtyStr      = fmtNum(data.qty),
                pricePct    = data.pricePct,
                isAnimal    = true,
            })
        end
    end
end

-- === ORDINAMENTO TAB 1+2 ===

function PriceAlertFrame:applySort(tabIndex)
    local col = PriceAlertFrame.sortColumn
    local asc = PriceAlertFrame.sortAsc
    local ok, err = pcall(function()
    table.sort(self.allRows, function(a, b)
        local va, vb
        if     col=="qty"       then va,vb=a.qty,      b.qty
        elseif col=="nowPrice"  then va,vb=a.nowPrice, b.nowPrice
        elseif col=="totalNow"  then va,vb=a.totalNow, b.totalNow
        elseif col=="maxPrice"  then va,vb=a.maxPrice, b.maxPrice
        elseif col=="bestMonth" then va,vb=a.bestMonth,b.bestMonth
        elseif col=="totalMax"  then va,vb=a.totalMax, b.totalMax
        elseif col=="pricePct"  then va,vb=a.pricePct, b.pricePct
        elseif col=="alert" then
            local function alertScore(row)
                local cfg = PriceAlertConfig.get(row.ftName)
                if cfg == nil then return 0 end
                if row.qty >= cfg.minQty and row.pricePct >= cfg.pctThreshold then return 2 end
                return 1
            end
            va,vb=alertScore(a),alertScore(b)
        else va,vb=a.title, b.title end
        if va==vb then
            if col ~= "pricePct" then return a.pricePct > b.pricePct end
            return a.title < b.title
        end
        if asc then return va<vb else return va>vb end
    end)
    end)
    if tabIndex == PriceAlertFrame.TAB_ALERT then
        self.rows = {}
        for _, row in ipairs(self.allRows) do
            if PriceAlertConfig.get(row.ftName) ~= nil then
                if PriceAlertFrame.showAnimals or not row.isAnimal then
                    table.insert(self.rows, row)
                end
            end
        end
    elseif tabIndex == PriceAlertFrame.TAB_UNSELLABLE then
        self.rows = {}
        for _, row in ipairs(self.allRows) do
            if row.noSellPoint then
                table.insert(self.rows, row)
            end
        end
    else
        if not PriceAlertFrame.showAnimals then
            self.rows = {}
            for _, row in ipairs(self.allRows) do
                if not row.isAnimal and not row.noSellPoint then table.insert(self.rows, row) end
            end
        else
            self.rows = {}
            for _, row in ipairs(self.allRows) do
                if not row.noSellPoint then table.insert(self.rows, row) end
            end
        end
    end
end

local function doSort(self, col)
    if PriceAlertFrame.sortColumn==col then PriceAlertFrame.sortAsc = not PriceAlertFrame.sortAsc
    else PriceAlertFrame.sortColumn=col; PriceAlertFrame.sortAsc=(col=="product") end
    self:applySort(self.currentTab)
    self:updateSortIndicators()
    if self.currentTab==1 and self.priceTable~=nil then self.priceTable:reloadData()
    elseif self.currentTab==2 and self.priceTableAlert~=nil then self.priceTableAlert:reloadData()
    elseif self.currentTab==3 and self.priceTableUnsellable~=nil then self.priceTableUnsellable:reloadData() end
end

function PriceAlertFrame:onClickSortProduct()   doSort(self,"product")   end
function PriceAlertFrame:onClickSortQty()       doSort(self,"qty")       end
function PriceAlertFrame:onClickSortNowPrice()  doSort(self,"nowPrice")  end
function PriceAlertFrame:onClickSortTotalNow()  doSort(self,"totalNow")  end
function PriceAlertFrame:onClickSortMaxPrice()  doSort(self,"maxPrice")  end
function PriceAlertFrame:onClickSortBestMonth() doSort(self,"bestMonth") end
function PriceAlertFrame:onClickSortTotalMax()  doSort(self,"totalMax")  end
function PriceAlertFrame:onClickSortPricePct()  doSort(self,"pricePct")  end
function PriceAlertFrame:onClickSortAlert()     doSort(self,"alert")     end

-- === ORDINAMENTO TAB 3 ===

function PriceAlertFrame:applySortTabConfig()
    local col=self.sortColumnConfig; local asc=self.sortAscConfig
    table.sort(self.allSellableRows, function(a, b)
        local va, vb
        local cfgA=PriceAlertConfig.get(a.ftName); local cfgB=PriceAlertConfig.get(b.ftName)
        if     col=="qty"    then va,vb=a.qty, b.qty
        elseif col=="pct"    then va=cfgA and cfgA.pctThreshold or -1; vb=cfgB and cfgB.pctThreshold or -1
        elseif col=="minqty" then va=cfgA and cfgA.minQty or -1; vb=cfgB and cfgB.minQty or -1
        elseif col=="stopts" then va=cfgA and (cfgA.stopTimeScale and 1 or 0) or -1; vb=cfgB and (cfgB.stopTimeScale and 1 or 0) or -1
        elseif col=="bell" then
            local function bellScore(row, cfg)
                if cfg == nil then return 0 end
                if row.qty >= cfg.minQty and row.pricePct >= cfg.pctThreshold then return 2 end
                return 1
            end
            va = bellScore(a, cfgA); vb = bellScore(b, cfgB)
        else                      va,vb=a.title, b.title end
        if va==vb then return a.title < b.title end
        if asc then return va<vb else return va>vb end
    end)
    self:updateSortIndicatorsConfig()
end

local function doSortConfig(self, col)
    if self.sortColumnConfig==col then self.sortAscConfig=not self.sortAscConfig
    else self.sortColumnConfig=col; self.sortAscConfig=(col=="product") end
    self:applySortTabConfig()
    if self.priceTableConfig~=nil then self.priceTableConfig:reloadData() end
end

function PriceAlertFrame:onClickSortProductConfig() doSortConfig(self,"product") end
function PriceAlertFrame:onClickSortQtyConfig()     doSortConfig(self,"qty")     end
function PriceAlertFrame:onClickSortPctConfig()     doSortConfig(self,"pct")     end
function PriceAlertFrame:onClickSortMinQtyConfig()  doSortConfig(self,"minqty")  end
function PriceAlertFrame:onClickSortStopTsConfig()  doSortConfig(self,"stopts")  end
function PriceAlertFrame:onClickSortBellConfig()    doSortConfig(self,"bell")    end

-- === DATA SOURCE ===

function PriceAlertFrame:getNumberOfItemsInSection(list, section)
    if list == self.priceTableConfig then return #self.allSellableRows end
    if list == self.priceTableUnsellable then return #self.rows end
    return #self.rows
end

function PriceAlertFrame:populateCellForItemInSection(list, section, index, cell)
    if list == self.priceTableConfig then
        self:populateCellTab3(index, cell)
        return
    end
    local row = self.rows[index]
    if row == nil then return end
    local icon = cell:getAttribute("colIcon")
    if icon~=nil then
        if row.hudOverlay~=nil and row.hudOverlay~="" then
            icon:setImageFilename(row.hudOverlay); icon:setVisible(true)
        else icon:setVisible(false) end
    end
    cell:getAttribute("colProduct"):setText(row.title)
    cell:getAttribute("colQty"):setText(row.qtyStr)
    cell:getAttribute("colStation"):setText(row.bestStation)
    cell:getAttribute("colNowPrice"):setText(row.priceStr)
    cell:getAttribute("colTotalNow"):setText(row.totalStr)
    local bm=cell:getAttribute("colBestMonth")
    bm:setText(row.bestMonthStr)
    if row.isAnimal then
        bm.textColor={0.85,0.85,0.85,1.0}; bm.textSelectedColor={0.1,0.1,0.1,1.0}
    elseif row.isCurrentMonth then
        bm.textColor={0.6,1.0,0.2,1.0}; bm.textSelectedColor={0.6,1.0,0.2,1.0}
    else
        bm.textColor={0.85,0.85,0.85,1.0}; bm.textSelectedColor={0.1,0.1,0.1,1.0}
    end
    cell:getAttribute("colMaxPrice"):setText(row.maxStr)
    cell:getAttribute("colTotalMax"):setText(row.totalMaxStr)
    cell:getAttribute("colPricePct"):setText(row.pctStr)
    local bell=cell:getAttribute("colAlertBell")
    if bell~=nil then
        local cfg = PriceAlertConfig.get(row.ftName)
        if cfg == nil then
            bell:setText("")
        elseif row.qty >= cfg.minQty and row.pricePct >= cfg.pctThreshold then
            bell:setText(g_i18n:getText("ui_alert_active") or "ATTIVO")
            bell.textColor = PriceAlert.alertBlinkState and {0.706, 1.0, 0.0, 1.0} or {1.0, 0.4, 0.0, 1.0}
            bell.textSelectedColor = PriceAlert.alertBlinkState and {0.706, 1.0, 0.0, 1.0} or {1.0, 0.4, 0.0, 1.0}
        else
            bell:setText(g_i18n:getText("ui_alert_configured") or "Configurato")
            bell.textColor = {0.85, 0.85, 0.85, 1.0}
            bell.textSelectedColor = {0.1, 0.1, 0.1, 1.0}
        end
    end
    -- Colore lampeggiante se alert attivo (verde <-> bianco), grigio altrimenti
    local alertColor, alertColorSel
    local cfg = PriceAlertConfig.get(row.ftName)
    local alertTriggered = cfg ~= nil and row.qty >= cfg.minQty and row.pricePct >= cfg.pctThreshold
    if alertTriggered then
        if PriceAlert.alertBlinkState then
            alertColor    = {0.706, 1.0, 0.0, 1.0}
            alertColorSel = {0.706, 1.0, 0.0, 1.0}
        else
            alertColor    = {1.0, 0.4, 0.0, 1.0}
            alertColorSel = {1.0, 0.4, 0.0, 1.0}
        end
    else
        alertColor    = {0.85, 0.85, 0.85, 1.0}
        alertColorSel = {0.1,  0.1,  0.1,  1.0}
    end
    for _, colName in ipairs({"colProduct","colQty","colStation","colNowPrice","colTotalNow","colMaxPrice","colTotalMax","colPricePct"}) do
        local e = cell:getAttribute(colName)
        if e ~= nil then e.textColor = alertColor; e.textSelectedColor = alertColorSel end
    end
end

function PriceAlertFrame:populateCellTab3(index, cell)
    local row = self.allSellableRows[index]
    if row == nil then return end
    local icon = cell:getAttribute("colIcon")
    if icon~=nil then
        if row.hudOverlay~=nil and row.hudOverlay~="" then icon:setImageFilename(row.hudOverlay); icon:setVisible(true)
        else icon:setVisible(false) end
    end
    cell:getAttribute("colProduct"):setText(row.title)
    local qtyElem=cell:getAttribute("colQty3"); if qtyElem~=nil then qtyElem:setText(row.qtyStr) end
    local cfg = PriceAlertConfig.get(row.ftName)
    local pctElem=cell:getAttribute("colPct3")
    if pctElem~=nil then pctElem:setText(cfg~=nil and tostring(cfg.pctThreshold).."%" or "-") end
    local minQtyElem=cell:getAttribute("colMinQty3")
    if minQtyElem~=nil then minQtyElem:setText(cfg~=nil and tostring(cfg.minQty) or "-") end
    local stopTsElem=cell:getAttribute("colStopTs3")
    if stopTsElem~=nil then
        if cfg~=nil then stopTsElem:setText(cfg.stopTimeScale and g_i18n:getText("button_yes") or g_i18n:getText("button_no"))
        else stopTsElem:setText("-") end
    end
    local bell=cell:getAttribute("colAlertBell3")
    if bell~=nil then
        if cfg == nil then
            bell:setText("")
        elseif row.qty >= cfg.minQty and row.pricePct >= cfg.pctThreshold then
            bell:setText(g_i18n:getText("ui_alert_active") or "ATTIVO")
            bell.textColor = PriceAlert.alertBlinkState and {0.706, 1.0, 0.0, 1.0} or {1.0, 0.4, 0.0, 1.0}
            bell.textSelectedColor = PriceAlert.alertBlinkState and {0.706, 1.0, 0.0, 1.0} or {1.0, 0.4, 0.0, 1.0}
        else
            bell:setText(g_i18n:getText("ui_alert_configured") or "Configurato")
            bell.textColor = {0.85, 0.85, 0.85, 1.0}; bell.textSelectedColor = {0.1, 0.1, 0.1, 1.0}
        end
    end
    local cfg3 = PriceAlertConfig.get(row.ftName)
    local alertTriggered3 = cfg3 ~= nil and row.qty >= cfg3.minQty and row.pricePct >= cfg3.pctThreshold
    local alertColor3, alertColorSel3
    if alertTriggered3 then
        alertColor3    = PriceAlert.alertBlinkState and {0.706, 1.0, 0.0, 1.0} or {1.0, 0.4, 0.0, 1.0}
        alertColorSel3 = PriceAlert.alertBlinkState and {0.706, 1.0, 0.0, 1.0} or {1.0, 0.4, 0.0, 1.0}
    else
        alertColor3    = {0.85, 0.85, 0.85, 1.0}
        alertColorSel3 = {0.1,  0.1,  0.1,  1.0}
    end
    for _, colName in ipairs({"colProduct","colQty3","colPct3","colMinQty3","colStopTs3"}) do
        local e = cell:getAttribute(colName)
        if e ~= nil then e.textColor = alertColor3; e.textSelectedColor = alertColorSel3 end
    end
end

function PriceAlertFrame:onClickTagStation()
    local row = self.selectedRow
    if row==nil then return end
    local hotspot = row.bestHotspot
    if hotspot==nil then return end
    if hotspot==g_currentMission.currentMapTargetHotspot then g_currentMission:setMapTargetHotspot(nil)
    else g_currentMission:setMapTargetHotspot(hotspot) end
    self:updateButtons()
end

function PriceAlertFrame:onClickToggleAnimals()
    PriceAlertFrame.showAnimals = not PriceAlertFrame.showAnimals
    self.toggleAnimalsButtonInfo.text = g_i18n:getText(
        PriceAlertFrame.showAnimals and "ui_btn_hide_animals" or "ui_btn_show_animals")
    self:setMenuButtonInfoDirty()
    self:collectData()
    self:applySort(self.currentTab)
    if self.currentTab==1 and self.priceTable~=nil then self.priceTable:reloadData()
    elseif self.currentTab==2 and self.priceTableAlert~=nil then self.priceTableAlert:reloadData() end
    self:updateBalanceDisplay()
end

function PriceAlertFrame:onClickConfigAlert()
    local row = self.selectedRow
    if row==nil or row.noSellPoint then return end
    local existing = PriceAlertConfig.get(row.ftName)
    local pct    = existing and existing.pctThreshold  or nil
    local minQty = existing and existing.minQty        or nil
    local stopTs = existing and existing.stopTimeScale or false
    PriceAlert.configDialog:setData(
        row.title, row.ftName, row.ftIndex, row.hudOverlay, pct, minQty, stopTs,
        function(ftIndex, ftName, newPct, newMinQty, newStopTs)
            PriceAlertConfig.set(ftName, newPct, newMinQty, newStopTs)
            if self.currentTab==1 and self.priceTable~=nil then self.priceTable:reloadData()
            elseif self.currentTab==2 and self.priceTableAlert~=nil then self.priceTableAlert:reloadData()
            elseif self.currentTab==3 and self.priceTableConfig~=nil then self.priceTableConfig:reloadData() end
        end,
        function(ftName)
            PriceAlertConfig.remove(ftName)
            if self.currentTab==1 and self.priceTable~=nil then self.priceTable:reloadData()
            elseif self.currentTab==2 and self.priceTableAlert~=nil then self.priceTableAlert:reloadData()
            elseif self.currentTab==3 and self.priceTableConfig~=nil then self.priceTableConfig:reloadData() end
        end
    )
    g_gui:showDialog("priceAlertConfigDialog")
end

function PriceAlertFrame:onClickStorages()
    local row = self.selectedRow
    if row == nil or row.qty <= 0 then return end
    if row.isAnimal then
        local enclosures = self:collectEnclosuresForAnimal(row.animalSubType)
        local dialogTitle = g_i18n:getText("ui_enclosure_dialogTitle")
        PriceAlert.storageDialog:setData(row.title, row.hudOverlay, enclosures, dialogTitle)
        g_gui:showDialog("priceAlertStorageDialog")
    else
        local cfg = PriceAlertConfig.get(row.ftName)
        local rowIsAlert = cfg ~= nil and row.qty >= cfg.minQty and row.pricePct >= cfg.pctThreshold
        local storages = self:collectStoragesForFillType(row.ftName, row.ftIndex, rowIsAlert)
        PriceAlert.storageDialog:setData(row.title, row.hudOverlay, storages)
        g_gui:showDialog("priceAlertStorageDialog")
    end
end

function PriceAlertFrame:collectStoragesForFillType(ftName, ftIndex, isAlert)
    local results = {}
    local seen    = {}
    local farmId  = g_currentMission:getFarmId()
    isAlert = isAlert or false
    local function fmtL(qty)
        if not qty or qty <= 0 then return "-" end
        local s = string.format("%d", math.floor(qty))
        local r = ""
        for i = 1, #s do
            if i > 1 and (#s - i + 1) % 3 == 0 then r = r .. "." end
            r = r .. s:sub(i, i)
        end
        return r
    end
    local function getHotspot(placeable)
        if placeable.spec_hotspots ~= nil then
            for _, h in ipairs(placeable.spec_hotspots.mapHotspots or {}) do
                if h.worldX ~= nil then return h end
            end
        end
        return nil
    end
    local function addResult(tag, name, level, canMark, hotspot)
        if level <= 0 then return end
        if seen[tag] then
            seen[tag].level = seen[tag].level + level
            seen[tag].qtyStr = fmtL(seen[tag].level)
        else
            local entry = { name=name, level=level, qtyStr=fmtL(level), canMark=canMark, hotspot=hotspot, isAlert=isAlert }
            seen[tag] = entry
            table.insert(results, entry)
        end
    end
    for v, placeable in ipairs(g_currentMission.placeableSystem.placeables) do
        local owned = placeable.ownerFarmId == farmId or placeable.ownerFarmId == 0
        local pName = placeable:getName() or ("Placeable"..tostring(v))
        if placeable.spec_silo ~= nil and owned then
            for _, storage in ipairs(placeable.spec_silo.storages) do
                if storage.ownerFarmId == farmId then
                    for fillTypeIndex, fillLevel in pairs(storage.fillLevels) do
                        if fillTypeIndex == ftIndex and fillLevel > 0 then
                            addResult("silo"..tostring(v), pName, fillLevel, getHotspot(placeable)~=nil, getHotspot(placeable))
                        end
                    end
                end
            end
        end
        if placeable.spec_siloExtension ~= nil and owned then
            local s = placeable.spec_siloExtension.storage
            if s and s.ownerFarmId == farmId then
                for fillTypeIndex, fillLevel in pairs(s.fillLevels) do
                    if fillTypeIndex == ftIndex and fillLevel > 0 then
                        addResult("siloext"..tostring(v), pName, fillLevel, getHotspot(placeable)~=nil, getHotspot(placeable))
                    end
                end
            end
        end
        if placeable.spec_husbandry ~= nil and placeable.ownerFarmId == farmId and placeable.spec_husbandry.storage ~= nil then
            for fillTypeIndex, fillLevel in pairs(placeable.spec_husbandry.storage.fillLevels) do
                if fillTypeIndex == ftIndex and fillLevel > 0 then
                    if placeable.spec_husbandry.loadingStation ~= nil and placeable.spec_husbandry.loadingStation.supportedFillTypes[ftIndex] then
                        addResult("husb"..tostring(v), pName, fillLevel, getHotspot(placeable)~=nil, getHotspot(placeable))
                    end
                end
            end
        end
        if placeable.spec_manureHeap ~= nil and placeable.ownerFarmId == farmId and placeable.spec_manureHeap.manureHeap ~= nil then
            for fillTypeIndex, fillLevel in pairs(placeable.spec_manureHeap.manureHeap.fillLevels) do
                if fillTypeIndex == ftIndex and fillLevel > 0 then
                    addResult("manure"..tostring(v), pName, fillLevel, getHotspot(placeable)~=nil, getHotspot(placeable))
                end
            end
        end
        if placeable.spec_bunkerSilo ~= nil and placeable.ownerFarmId == farmId and placeable.spec_bunkerSilo.bunkerSilo ~= nil then
            local bs = placeable.spec_bunkerSilo.bunkerSilo
            local bsFtIdx, bsLevel = nil, 0
            if bs.state == BunkerSilo.STATE_FILL or bs.state == BunkerSilo.STATE_CLOSED then
                bsFtIdx = bs.inputFillType; bsLevel = bs.fillLevel
            elseif bs.state == BunkerSilo.STATE_DRAIN or bs.state == BunkerSilo.STATE_FERMENTED then
                bsFtIdx = bs.outputFillType; bsLevel = bs.fillLevel
            end
            if bsFtIdx == ftIndex and bsLevel > 0 then
                addResult("bunker"..tostring(v), pName, bsLevel, getHotspot(placeable)~=nil, getHotspot(placeable))
            end
        end
        if placeable.spec_objectStorage ~= nil and placeable.spec_objectStorage.objectInfos ~= nil and placeable.ownerFarmId == farmId then
            local totalLevel = 0
            for _, info in ipairs(placeable.spec_objectStorage.objectInfos) do
                if #info.objects == 1 and info.numObjects ~= 1 then
                    local objFtIdx, level = 0, 0
                    if info.objects[1].baleAttributes then objFtIdx=info.objects[1].baleAttributes.fillType; level=info.objects[1].baleAttributes.fillLevel*info.numObjects
                    elseif info.objects[1].baleObject then objFtIdx=info.objects[1].baleObject.fillType; level=info.objects[1].baleObject.fillLevel*info.numObjects
                    elseif info.objects[1].palletAttributes then objFtIdx=info.objects[1].palletAttributes.fillType; level=info.objects[1].palletAttributes.fillLevel*info.numObjects end
                    if objFtIdx == ftIndex then totalLevel = totalLevel + level end
                else
                    for _, obj in ipairs(info.objects) do
                        local objFtIdx, level = 0, 0
                        if obj.baleAttributes and obj.baleAttributes.farmId == farmId then objFtIdx=obj.baleAttributes.fillType; level=obj.baleAttributes.fillLevel
                        elseif obj.baleObject and obj.baleObject.ownerFarmId == farmId then objFtIdx=obj.baleObject.fillType; level=obj.baleObject.fillLevel
                        elseif obj.palletAttributes and obj.palletAttributes.ownerFarmId == farmId then objFtIdx=obj.palletAttributes.fillType; level=obj.palletAttributes.fillLevel end
                        if objFtIdx == ftIndex then totalLevel = totalLevel + level end
                    end
                end
            end
            if totalLevel > 0 then addResult("objstorage"..tostring(v), pName, totalLevel, false, nil) end
        end
    end
    if g_currentMission.productionChainManager then
        for v, prod in ipairs(g_currentMission.productionChainManager.productionPoints) do
            if prod:getOwnerFarmId() == farmId then
                local isOutput = false
                for _, outFtIdx in ipairs(prod.outputFillTypeIdsArray) do
                    if outFtIdx == ftIndex then isOutput = true; break end
                end
                if isOutput then
                    local level = prod.storage:getFillLevel(ftIndex)
                    if level > 0 then
                        local hs = nil
                        if prod.owningPlaceable ~= nil and prod.owningPlaceable.spec_hotspots ~= nil then
                            for _, h in ipairs(prod.owningPlaceable.spec_hotspots.mapHotspots or {}) do
                                if h.worldX ~= nil then hs = h; break end
                            end
                        end
                        addResult("prod"..tostring(v), prod:getName() or "Produzione", level, hs~=nil, hs)
                    end
                end
            end
        end
    end
    if g_currentMission.itemSystem then
        local baleQty = 0
        for _, item in pairs(g_currentMission.itemSystem.itemsToSave) do
            local bale = item.item
            if bale.isa ~= nil and bale:isa(Bale) and bale.ownerFarmId == farmId and bale.fillType == ftIndex then
                baleQty = baleQty + bale.fillLevel
            end
        end
        if baleQty > 0 then
            addResult("loosebales", g_i18n:getText("ui_storage_looseBales") or "Balle nel campo", baleQty, false, nil)
        end
    end
    if g_currentMission.vehicleSystem then
        local palletQty = 0
        for _, vehicle in ipairs(g_currentMission.vehicleSystem.vehicles) do
            if vehicle.ownerFarmId == farmId and vehicle.isPallet and vehicle.spec_fillUnit ~= nil and #vehicle.spec_fillUnit.fillUnits > 0 then
                local fu = vehicle.spec_fillUnit.fillUnits[1]
                if fu.fillType == ftIndex and fu.fillLevel > 0 then
                    palletQty = palletQty + fu.fillLevel
                end
            end
        end
        if palletQty > 0 then
            addResult("loosepallet", g_i18n:getText("ui_storage_loosePallets") or "Pallet", palletQty, false, nil)
        end
    end
    -- Veicoli e rimorchi (non pallet)
    if g_currentMission.vehicleSystem then
        for vi, vehicle in ipairs(g_currentMission.vehicleSystem.vehicles) do
            if vehicle.ownerFarmId == farmId and not vehicle.isPallet and vehicle.getFillUnits ~= nil then
                local fillUnits = vehicle:getFillUnits()
                if fillUnits ~= nil then
                    local vehicleTotal = 0
                    for i, _ in ipairs(fillUnits) do
                        local fType = vehicle:getFillUnitFillType(i)
                        local fLevel = vehicle:getFillUnitFillLevel(i)
                        if fType == ftIndex and fLevel > 0 then
                            vehicleTotal = vehicleTotal + fLevel
                        end
                    end
                    if vehicleTotal > 0 then
                        local vName = vehicle:getName() or ("Veicolo " .. tostring(vi))
                        local wx, _, wz = getWorldTranslation(vehicle.rootNode)
                        addResult("vehicle"..tostring(vi), vName, vehicleTotal, wx ~= nil, nil)
                        if wx ~= nil then
                            seen["vehicle"..tostring(vi)].worldX = wx
                            seen["vehicle"..tostring(vi)].worldZ = wz
                            seen["vehicle"..tostring(vi)].isVehicle = true
                            seen["vehicle"..tostring(vi)].vehicleId = vehicle.rootNode
                        end
                    end
                end
            end
        end
    end
    return results
end

function PriceAlertFrame:collectEnclosuresForAnimal(animalSubType)
    local results = {}
    local farmId = g_currentMission:getFarmId()
    local function fmtL(qty)
        if not qty or qty <= 0 then return "-" end
        local s = string.format("%d", math.floor(qty))
        local r = ""
        for i = 1, #s do
            if i > 1 and (#s - i + 1) % 3 == 0 then r = r .. "." end
            r = r .. s:sub(i, i)
        end
        return r
    end
    -- Recupera pricePct per recinto dalla collectRawData (già calcolato)
    local _, animalsByPlaceable = PriceAlertFrame.collectRawData()
    local cfg = PriceAlertConfig.get("animal_" .. animalSubType)
    local pctThreshold = cfg and cfg.pctThreshold or nil
    for _, placeable in ipairs(g_currentMission.placeableSystem.placeables) do
        if placeable.spec_husbandryAnimals ~= nil and placeable.ownerFarmId == farmId then
            local spec = placeable.spec_husbandryAnimals
            if spec.clusterSystem ~= nil then
                local count = 0
                for _, cluster in ipairs(spec.clusterSystem:getClusters()) do
                    local subType = g_currentMission.animalSystem:getSubTypeByIndex(cluster:getSubTypeIndex())
                    if subType and subType.name == animalSubType then
                        count = count + (cluster.numAnimals or 0)
                    end
                end
                if count > 0 then
                    local hs = nil
                    local pName = placeable:getName() or "Recinto"
                    if placeable.spec_hotspots ~= nil then
                        for _, h in ipairs(placeable.spec_hotspots.mapHotspots or {}) do
                            if h.worldX ~= nil then hs = h; break end
                        end
                    end
                    -- Usa nome hotspot se disponibile (è quello visibile in mappa)
                    if hs ~= nil and hs.name ~= nil and hs.name ~= "" then
                        pName = hs.name
                    end
                    -- isAlert: true se almeno un cluster in questo recinto ha pricePct >= soglia
                    local isAlert = false
                    if pctThreshold ~= nil and animalsByPlaceable[placeable] ~= nil then
                        local abp = animalsByPlaceable[placeable][animalSubType]
                        if abp ~= nil and abp.maxPricePct >= pctThreshold then
                            isAlert = true
                        end
                    end
                    table.insert(results, { name=pName, level=count, qtyStr=fmtL(count), canMark=hs~=nil, hotspot=hs, isAlert=isAlert })
                end
            end
        end
    end
    return results
end

function PriceAlertFrame:onClickSellPoints()
    local row = self.selectedRow
    if row == nil or row.noSellPoint then return end
    if row.isAnimal then
        -- Per gli animali mostra il mercante di bestiame come unico punto vendita
        local sellPoints = {}
        if row.bestHotspot ~= nil then
            table.insert(sellPoints, {
                name        = row.bestStation,
                totalNow    = row.totalNow,
                totalNowStr = row.totalNow > 0 and g_i18n:formatMoney(row.totalNow, 0, true, true) or "-",
                totalMax    = row.totalMax,
                totalMaxStr = row.totalMax > 0 and g_i18n:formatMoney(row.totalMax, 0, true, true) or "-",
                pct         = row.pricePct,
                pctStr      = row.pctStr,
                hotspot     = row.bestHotspot,
            })
        end
        PriceAlert.sellPointDialog:setData(row.title, row.hudOverlay, sellPoints)
        g_gui:showDialog("priceAlertSellPointDialog")
    else
        local sellPoints = self:collectSellPointsForFillType(row.ftName, row.ftIndex, row.qty)
        PriceAlert.sellPointDialog:setData(row.title, row.hudOverlay, sellPoints)
        g_gui:showDialog("priceAlertSellPointDialog")
    end
end

function PriceAlertFrame:collectSellPointsForFillType(ftName, ftIndex, qty)
    local results = {}
    local farmId  = g_currentMission:getFarmId()
    local mult    = EconomyManager.getPriceMultiplier()
    local maxPrice = 0
    local ft = g_fillTypeManager:getFillTypeByIndex(ftIndex)
    if ft ~= nil and ft.economy and ft.economy.factors then
        for period = SeasonPeriod.EARLY_SPRING, SeasonPeriod.LATE_WINTER do
            local p = (ft.pricePerLiter or 0) * (ft.economy.factors[period] or 1) * mult
            if p > maxPrice then maxPrice = p end
        end
    end
    for _, station in pairs(g_currentMission.storageSystem:getUnloadingStations()) do
        if station:isa(SellingStation) and not station.hideFromPricesMenu then
            if station.ownerFarmId ~= farmId then
                local isAccepted = station.acceptedFillTypes[ftIndex]
                if isAccepted then
                    local price = station:getEffectiveFillTypePrice(ftIndex)
                    if price and price > 0 then
                        local totalNow = price * qty
                        local totalMax = maxPrice * qty
                        local pct = 0
                        if maxPrice > 0 then pct = math.floor((price / maxPrice) * 100) end
                        local hs = nil
                        if station.owningPlaceable ~= nil and station.owningPlaceable.spec_hotspots ~= nil then
                            for _, h in ipairs(station.owningPlaceable.spec_hotspots.mapHotspots or {}) do
                                if h.worldX ~= nil then hs = h; break end
                            end
                        end
                        if hs == nil and station.spec_sellingStation ~= nil and station.spec_sellingStation.spec_hotspots ~= nil then
                            for _, h in ipairs(station.spec_sellingStation.spec_hotspots.mapHotspots or {}) do
                                if h.worldX ~= nil then hs = h; break end
                            end
                        end
                        table.insert(results, {
                            name        = station:getName() or "-",
                            totalNow    = totalNow,
                            totalNowStr = g_i18n:formatMoney(totalNow, 0, true, true),
                            totalMax    = totalMax,
                            totalMaxStr = g_i18n:formatMoney(totalMax, 0, true, true),
                            pct         = pct,
                            pctStr      = string.format("%d%%", pct),
                            hotspot     = hs,
                        })
                    end
                end
            end
        end
    end
    table.sort(results, function(a, b) return a.totalNow > b.totalNow end)
    return results
end
