-- PriceAlertNotifyDialog.lua

PriceAlertNotifyDialog = {}
local PriceAlertNotifyDialog_mt = Class(PriceAlertNotifyDialog, MessageDialog)

function PriceAlertNotifyDialog.new(target, custom_mt)
    local self = MessageDialog.new(target, custom_mt or PriceAlertNotifyDialog_mt)
    return self
end

function PriceAlertNotifyDialog:onGuiSetupFinished()
    PriceAlertNotifyDialog:superClass().onGuiSetupFinished(self)
end

function PriceAlertNotifyDialog:initialize()
end

function PriceAlertNotifyDialog:open()
    PriceAlertNotifyDialog:superClass().open(self)
end

function PriceAlertNotifyDialog:onOpen()
    PriceAlertNotifyDialog:superClass().onOpen(self)
    if g_inputBinding ~= nil and g_inputBinding.setShowMouseCursor ~= nil then
        g_inputBinding:setShowMouseCursor(true)
    end
    if showPointer ~= nil then
        showPointer(true)
    end
end

function PriceAlertNotifyDialog:onClose()
    PriceAlertNotifyDialog:superClass().onClose(self)
    if g_inputBinding ~= nil and g_inputBinding.setShowMouseCursor ~= nil then
        g_inputBinding:setShowMouseCursor(false)
    end
    if showPointer ~= nil then
        showPointer(false)
    end
end

function PriceAlertNotifyDialog:onClickOpenMenu()
    if g_inputBinding ~= nil and g_inputBinding.setShowMouseCursor ~= nil then
        g_inputBinding:setShowMouseCursor(false)
    end
    if showPointer ~= nil then showPointer(false) end
    self:close()
    PriceAlert.openMenu()
end

function PriceAlertNotifyDialog:onClickOk()
    if g_inputBinding ~= nil and g_inputBinding.setShowMouseCursor ~= nil then
        g_inputBinding:setShowMouseCursor(false)
    end
    if showPointer ~= nil then showPointer(false) end
    self:close()
end
