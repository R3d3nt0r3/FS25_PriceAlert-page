-- PriceAlert.lua

PriceAlert = {}
PriceAlert.dir = g_currentModDirectory

source(PriceAlert.dir .. "gui/PriceAlertFrame.lua")
source(PriceAlert.dir .. "gui/PriceAlertConfigDialog.lua")
source(PriceAlert.dir .. "gui/PriceAlertStorageDialog.lua")
source(PriceAlert.dir .. "gui/PriceAlertSellPointDialog.lua")
source(PriceAlert.dir .. "gui/PriceAlertNotifyDialog.lua")
source(PriceAlert.dir .. "scripts/PriceAlertConfig.lua")

function PriceAlert:loadMap()
    g_gui:loadProfiles(PriceAlert.dir .. "gui/guiProfiles.xml")

    PriceAlert.frame = PriceAlertFrame.new()
    g_gui:loadGui(PriceAlert.dir .. "gui/PriceAlertFrame.xml", "priceAlertAllProducts", PriceAlert.frame, true)

    PriceAlert.configDialog = PriceAlertConfigDialog.new()
    g_gui:loadGui(PriceAlert.dir .. "gui/PriceAlertConfigDialog.xml", "priceAlertConfigDialog", PriceAlert.configDialog, false)

    PriceAlert.storageDialog = PriceAlertStorageDialog.new()
    g_gui:loadGui(PriceAlert.dir .. "gui/PriceAlertStorageDialog.xml", "priceAlertStorageDialog", PriceAlert.storageDialog, false)

    PriceAlert.sellPointDialog = PriceAlertSellPointDialog.new()
    g_gui:loadGui(PriceAlert.dir .. "gui/PriceAlertSellPointDialog.xml", "priceAlertSellPointDialog", PriceAlert.sellPointDialog, false)

    PriceAlert.notifyDialog = PriceAlertNotifyDialog.new()
    g_gui:loadGui(PriceAlert.dir .. "gui/PriceAlertNotifyDialog.xml", "priceAlertNotifyDialog", PriceAlert.notifyDialog, false)

    PriceAlert.fixInGameMenu(PriceAlert.frame, "priceAlertAllProducts", function() return true end)
    PriceAlert.frame:initialize()
    PriceAlert.configDialog:initialize()
    PriceAlert.storageDialog:initialize()
    PriceAlert.sellPointDialog:initialize()

    -- Carica configurazione subito
    PriceAlertConfig.load()

    -- Registra listener cambio ora
    g_messageCenter:subscribe(MessageType.HOUR_CHANGED, PriceAlert.onHourChanged, PriceAlert)

    -- Inizializza stato alert
    PriceAlert.triggeredAlerts = {}

    -- Aggancia il salvataggio automatico in modo sicuro
    ItemSystem.save = Utils.prependedFunction(ItemSystem.save, function()
        if g_currentMission ~= nil then
            PriceAlertConfig.save()
        end
    end)

    -- Carica sample audio per l'alert
    PriceAlert.alertSample = createSample("PriceAlert_Success")
    loadSample(PriceAlert.alertSample, "data/sounds/ui/uiSuccess.ogg", false)

    -- Variabile globale per hotspot veicolo corrente
    PriceAlert.currentVehicleHotspot = nil
    PriceAlert.currentVehicleId = nil

    print("[PriceAlert] Pagina aggiunta all'InGameMenu")
end

function PriceAlert.fixInGameMenu(frame, pageName, predicateFunc)
    local inGameMenu = g_gui.screenControllers[InGameMenu]

    inGameMenu.controlIDs[pageName] = nil

    local insertPos = 2
    for i = 1, #inGameMenu.pagingElement.elements do
        if inGameMenu.pagingElement.elements[i] == inGameMenu["pageStatistics"] then
            insertPos = i
            break
        end
    end

    inGameMenu[pageName] = frame
    inGameMenu.pagingElement:addElement(inGameMenu[pageName])
    inGameMenu:exposeControlsAsFields(pageName)

    for i = 1, #inGameMenu.pagingElement.elements do
        if inGameMenu.pagingElement.elements[i] == inGameMenu[pageName] then
            table.remove(inGameMenu.pagingElement.elements, i)
            table.insert(inGameMenu.pagingElement.elements, insertPos, inGameMenu[pageName])
            break
        end
    end

    for i = 1, #inGameMenu.pagingElement.pages do
        local child = inGameMenu.pagingElement.pages[i]
        if child.element == inGameMenu[pageName] then
            table.remove(inGameMenu.pagingElement.pages, i)
            table.insert(inGameMenu.pagingElement.pages, insertPos, child)
            break
        end
    end

    inGameMenu.pagingElement:updateAbsolutePosition()
    inGameMenu.pagingElement:updatePageMapping()
    inGameMenu:registerPage(inGameMenu[pageName], insertPos, predicateFunc)

    local iconFilename = Utils.getFilename("gui/palert_menu_icon.dds", PriceAlert.dir)
    inGameMenu:addPageTab(inGameMenu[pageName], iconFilename, GuiUtils.getUVs({0, 0, 1024, 1024}))

    for i = 1, #inGameMenu.pageFrames do
        if inGameMenu.pageFrames[i] == inGameMenu[pageName] then
            table.remove(inGameMenu.pageFrames, i)
            table.insert(inGameMenu.pageFrames, insertPos, inGameMenu[pageName])
            break
        end
    end

    inGameMenu:rebuildTabList()
    print("[PriceAlert] fixInGameMenu: completato")
end

function PriceAlert:deleteMap()
    if g_messageCenter ~= nil then
        g_messageCenter:unsubscribe(MessageType.HOUR_CHANGED, PriceAlert.onHourChanged, PriceAlert)
    end
    if PriceAlert.alertSample ~= nil then
        if deleteSample ~= nil then
            deleteSample(PriceAlert.alertSample)
        end
        PriceAlert.alertSample = nil
    end
    if PriceAlert.currentVehicleHotspot ~= nil then
        if g_currentMission ~= nil then
            g_currentMission:removeMapHotspot(PriceAlert.currentVehicleHotspot)
        end
        PriceAlert.currentVehicleHotspot:delete()
        PriceAlert.currentVehicleHotspot = nil
        PriceAlert.currentVehicleId = nil
    end
    if g_currentMission ~= nil then
        PriceAlertConfig.save()
    end
end

function PriceAlert:saveToXMLFile(xmlFile, key, usedModNames)
    PriceAlertConfig.save()
end

function PriceAlert:update(dt)
    -- Timer lampeggio righe alert (alterna ogni 600ms)
    PriceAlert.alertBlinkTimer = (PriceAlert.alertBlinkTimer or 0) + dt
    if PriceAlert.alertBlinkTimer >= 600 then
        PriceAlert.alertBlinkTimer = 0
        PriceAlert.alertBlinkState = not (PriceAlert.alertBlinkState or false)
        -- Forza il ridisegno delle celle visibili
        local inGameMenu = g_gui.screenControllers[InGameMenu]
        if inGameMenu ~= nil and inGameMenu.priceAlertAllProducts ~= nil then
            local frame = inGameMenu.priceAlertAllProducts
            if frame.priceTable ~= nil then frame.priceTable:reloadData() end
            if frame.priceTableAlert ~= nil then frame.priceTableAlert:reloadData() end
            if frame.priceTableUnsellable ~= nil then frame.priceTableUnsellable:reloadData() end
            if frame.priceTableConfig ~= nil then frame.priceTableConfig:reloadData() end
        end
    end
    -- Controlla ogni 500ms se il target della mappa è cambiato rispetto al nostro hotspot veicolo
    PriceAlert.vehicleHotspotCheckTimer = (PriceAlert.vehicleHotspotCheckTimer or 0) + dt
    if PriceAlert.vehicleHotspotCheckTimer >= 500 then
        PriceAlert.vehicleHotspotCheckTimer = 0
        if PriceAlert.currentVehicleHotspot ~= nil then
            if g_currentMission.currentMapTargetHotspot ~= PriceAlert.currentVehicleHotspot then
                g_currentMission:removeMapHotspot(PriceAlert.currentVehicleHotspot)
                PriceAlert.currentVehicleHotspot:delete()
                PriceAlert.currentVehicleHotspot = nil
                PriceAlert.currentVehicleId = nil
            end
        end
    end
end

function PriceAlert.onHourChanged()
    local configs = PriceAlertConfig.getAll()
    if configs == nil or next(configs) == nil then return end

    local currentTimeScale = g_currentMission.missionInfo and g_currentMission.missionInfo.timeScale or 1
    local rawData = PriceAlertFrame.collectRawData()

    local newTriggered = {}
    local needStopSleep = false

    -- Aggrega i dati dei cavalli per razza (somma qty dei cluster sopra soglia)
    local horseDataByRace = {}
    for ftName, data in pairs(rawData) do
        if data.isAnimal and data.isHorse then
            local raceName = "animal_" .. data.animalSubTypeName
            if horseDataByRace[raceName] == nil then
                horseDataByRace[raceName] = { totalQty = 0, qtyAboveThreshold = 0, maxPricePct = 0 }
            end
            horseDataByRace[raceName].totalQty = horseDataByRace[raceName].totalQty + data.qty
            if data.pricePct > horseDataByRace[raceName].maxPricePct then
                horseDataByRace[raceName].maxPricePct = data.pricePct
            end
        end
    end

    for ftName, cfg in pairs(configs) do
        -- Controlla se è una razza di cavalli
        local isHorseConfig = false
        for raceName, _ in pairs(horseDataByRace) do
            if raceName == ftName then isHorseConfig = true; break end
        end

        if isHorseConfig then
            -- Logica cavalli: somma qty dei cluster che superano la soglia percentuale
            local horseData = horseDataByRace[ftName]
            if horseData ~= nil then
                -- Conta qty dei cluster che superano la soglia
                local qtyAboveThreshold = 0
                for hftName, hdata in pairs(rawData) do
                    if hdata.isAnimal and hdata.isHorse then
                        local raceName = "animal_" .. hdata.animalSubTypeName
                        if raceName == ftName and hdata.pricePct >= cfg.pctThreshold then
                            qtyAboveThreshold = qtyAboveThreshold + hdata.qty
                        end
                    end
                end
                local triggered = qtyAboveThreshold >= cfg.minQty
                if triggered and not PriceAlert.triggeredAlerts[ftName] then
                    newTriggered[ftName] = true
                    if cfg.stopTimeScale then needStopSleep = true end
                elseif triggered then
                    newTriggered[ftName] = true
                end
            end
        else
            -- Logica normale per tutti gli altri animali e prodotti
            local data = rawData[ftName]
            if data ~= nil then
                local triggered = data.qty >= cfg.minQty and data.pricePct >= cfg.pctThreshold
                if triggered and not PriceAlert.triggeredAlerts[ftName] then
                    newTriggered[ftName] = true
                    if cfg.stopTimeScale then needStopSleep = true end
                elseif triggered then
                    newTriggered[ftName] = true
                end
            end
        end
    end

    -- Decisione unica alert: se almeno un prodotto/animale ha superato soglie per la prima volta
    -- se timeScale > 1 E almeno uno ha stopTimeScale=true -> alert invasivo, altrimenti non invasivo
    local needBlinkAlert = false
    if needStopSleep and currentTimeScale <= 1 then
        needStopSleep = false
        needBlinkAlert = true
    elseif not needStopSleep then
        for ftName, _ in pairs(newTriggered) do
            if not PriceAlert.triggeredAlerts[ftName] then
                needBlinkAlert = true
                break
            end
        end
    end

    -- Interrompe sonno/velocità se necessario
    if needStopSleep then
        print("[PriceAlert] Alert: riporto velocità a 1x")
        if g_currentMission.setTimeScale ~= nil then
            g_currentMission:setTimeScale(1)
        end
        print("[PriceAlert] Chiamo showDialog priceAlertNotifyDialog")
        g_gui:showDialog("priceAlertNotifyDialog")
        print("[PriceAlert] showDialog completato")
        if PriceAlert.alertSample ~= nil then
            playSample(PriceAlert.alertSample, 1, 1, 0, 0, 0)
        end
        if g_inputBinding ~= nil and g_inputBinding.setShowMouseCursor ~= nil then
            g_inputBinding:setShowMouseCursor(true)
        end
        if showPointer ~= nil then
            showPointer(true)
        end
    end

    -- Aggiorna stato alert (per prevenire spam)
    PriceAlert.triggeredAlerts = newTriggered

    -- Attiva alert lampeggiante nativo FS25
    if needBlinkAlert then
        local msg = g_i18n:getText("ui_alert_blink_msg") or "Hai prodotti pronti per la vendita!"
        if g_currentMission ~= nil and g_currentMission.showBlinkingWarning ~= nil then
            g_currentMission:showBlinkingWarning(msg, 8000)
        end
        if PriceAlert.alertSample ~= nil then
            playSample(PriceAlert.alertSample, 1, 1, 0, 0, 0)
        end
    end
end

function PriceAlert.openMenu()
    local inGameMenu = g_gui.screenControllers[InGameMenu]
    if g_gui:getIsGuiVisible() then
        if g_gui.currentGui == inGameMenu then
            inGameMenu:onMenuBack()
        end
    else
        g_gui:showGui("InGameMenu")
        if inGameMenu ~= nil and inGameMenu.priceAlertAllProducts ~= nil then
            inGameMenu:goToPage(inGameMenu.priceAlertAllProducts)
            inGameMenu.priceAlertAllProducts:switchTab(PriceAlertFrame.TAB_ALERT)
        end
    end
end

addModEventListener(PriceAlert)
