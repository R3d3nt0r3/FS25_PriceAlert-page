-- PriceAlertConfig.lua
-- Gestione salvataggio e caricamento configurazione alert prodotti

PriceAlertConfig = {}
PriceAlertConfig.data = {}

local CONFIG_KEY = "priceAlertConfig"

function PriceAlertConfig.load()
    PriceAlertConfig.data = {}
    local path = PriceAlertConfig.getFilePath()
    if path == nil then return end
    if not fileExists(path) then return end
    local xmlFile = loadXMLFile(CONFIG_KEY, path)
    if xmlFile == nil or xmlFile == 0 then return end
    local i = 0
    while true do
        local key = string.format("%s.product(%d)", CONFIG_KEY, i)
        if not hasXMLProperty(xmlFile, key) then break end
        local name = getXMLString(xmlFile, key .. "#name") or ""
        local pct  = getXMLInt(xmlFile,    key .. "#pctThreshold") or 80
        local qty  = getXMLInt(xmlFile,    key .. "#minQty") or 0
        local stop = getXMLBool(xmlFile,   key .. "#stopTimeScale") or false
        if name ~= "" then
            PriceAlertConfig.data[name] = { pctThreshold = pct, minQty = qty, stopTimeScale = stop }
        end
        i = i + 1
    end
    delete(xmlFile)
    print(string.format("[PriceAlert] Configurazione caricata: %d prodotti", i))
end

function PriceAlertConfig.getFilePath()
    if g_currentMission and g_currentMission.missionInfo then
        local dir = g_currentMission.missionInfo.savegameDirectory
        if dir == nil or dir == "" then
            print("[PriceAlert] getFilePath: savegameDirectory nil (nuova partita), skip")
            return nil
        end
        return dir .. "/priceAlertConfig.xml"
    end
    return nil
end

function PriceAlertConfig.save()
    local path = PriceAlertConfig.getFilePath()
    if path == nil then return end
    local xmlFile = createXMLFile(CONFIG_KEY, path, CONFIG_KEY)
    if xmlFile == nil or xmlFile == 0 then
        print("[PriceAlert] Errore creazione file XML")
        return
    end
    local i = 0
    for name, cfg in pairs(PriceAlertConfig.data) do
        local key = string.format("%s.product(%d)", CONFIG_KEY, i)
        setXMLString(xmlFile, key .. "#name",         name)
        setXMLInt(   xmlFile, key .. "#pctThreshold", cfg.pctThreshold)
        setXMLInt(   xmlFile, key .. "#minQty",       cfg.minQty)
        setXMLBool(  xmlFile, key .. "#stopTimeScale",cfg.stopTimeScale or false)
        i = i + 1
    end
    saveXMLFile(xmlFile)
    delete(xmlFile)
    print(string.format("[PriceAlert] Configurazione salvata: %d prodotti", i))
end

function PriceAlertConfig.set(ftName, pctThreshold, minQty, stopTimeScale)
    PriceAlertConfig.data[ftName] = {
        pctThreshold  = pctThreshold,
        minQty        = minQty,
        stopTimeScale = stopTimeScale or false,
    }
    PriceAlertConfig.save()
end

function PriceAlertConfig.get(ftName)
    return PriceAlertConfig.data[ftName]
end

function PriceAlertConfig.getAll()
    return PriceAlertConfig.data
end

function PriceAlertConfig.remove(ftName)
    if PriceAlertConfig.data[ftName] ~= nil then
        PriceAlertConfig.data[ftName] = nil
        PriceAlertConfig.save()
        print(string.format("[PriceAlert] Alert rimosso per: %s", tostring(ftName)))
    else
        print(string.format("[PriceAlert] remove: nessun alert trovato per: %s", tostring(ftName)))
    end
end
